import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  FabricOption,
  ServiceItem,
  ShopSettings,
} from '../types';
import {
  Scissors,
  Check,
  Clock,
  Sparkles,
  ArrowRight,
  Info,
} from 'lucide-react';

interface ServicesShowcaseProps {
  services: ServiceItem[];
  fabrics: FabricOption[];
  shopSettings: ShopSettings;
  onSelectServiceForInquiry: (serviceTitle: string, fabricName?: string) => void;
}

export const ServicesShowcase: React.FC<ServicesShowcaseProps> = ({
  services,
  fabrics,
  shopSettings,
  onSelectServiceForInquiry,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedFabric, setSelectedFabric] = useState<FabricOption | null>(fabrics[0] || null);

  const categories = [
    { id: 'all', label: 'All Offerings' },
    { id: 'bespoke_suit', label: 'Bespoke Suits' },
    { id: 'tuxedo', label: 'Wedding Tuxedos' },
    { id: 'traditional', label: 'Heritage Attire' },
    { id: 'alteration', label: 'Master Alterations' },
  ];

  const filteredServices = services.filter((s) => {
    if (selectedCategory === 'all') return true;
    return s.category === selectedCategory;
  });

  return (
    <section className="py-16 bg-[#FAF9F6] text-stone-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-xs uppercase tracking-widest text-[#C5A059] font-semibold">
            Bespoke Services & Fine Textiles
          </span>
          <h2 className="font-serif-title text-3xl sm:text-4xl font-normal text-stone-900">
            Crafted with Uncompromising Integrity
          </h2>
          <p className="text-stone-600 text-sm sm:text-base font-light leading-relaxed">
            Every garment from Atelier Haute is cut individually from an anatomical paper pattern created specifically for your posture and measurements.
          </p>
        </div>

        {/* Category Selector Tabs */}
        <div className="flex items-center justify-center flex-wrap gap-2 pb-4 border-b border-stone-200">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-full text-xs font-medium tracking-wide uppercase transition-all ${
                selectedCategory === cat.id
                  ? 'bg-stone-900 text-white shadow-sm'
                  : 'bg-stone-200/60 text-stone-700 hover:bg-stone-300/60'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredServices.map((service) => (
            <div
              key={service.id}
              className="bg-white border border-stone-200 rounded-lg overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between group"
            >
              <div>
                {/* Image & Price Tag */}
                <div className="relative h-56 overflow-hidden bg-stone-100">
                  <img
                    src={service.imageUrl}
                    alt={service.title}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-3 right-3 bg-stone-900/90 text-stone-100 px-3 py-1 rounded-md text-xs font-semibold backdrop-blur-xs">
                    From ₦{service.startingPrice.toLocaleString()}
                  </div>
                  <div className="absolute bottom-3 left-3 bg-white/90 text-stone-900 px-2.5 py-1 rounded text-[11px] font-medium flex items-center gap-1.5 shadow-xs">
                    <Clock className="w-3 h-3 text-[#C5A059]" />
                    <span>{service.turnaroundDays} Days Turnaround</span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 space-y-4">
                  <h3 className="font-serif-title text-2xl font-normal text-stone-900">
                    {service.title}
                  </h3>

                  <p className="text-stone-600 text-xs font-light leading-relaxed">
                    {service.description}
                  </p>

                  <div className="space-y-2 pt-2 border-t border-stone-100">
                    <span className="text-[11px] uppercase tracking-wider text-stone-400 font-semibold block">
                      Key Atelier Specifications
                    </span>
                    <ul className="space-y-1.5 text-xs text-stone-700">
                      {service.features.map((feat, idx) => (
                        <li key={idx} className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="p-6 pt-0">
                <button
                  onClick={() =>
                    onSelectServiceForInquiry(
                      service.title,
                      selectedFabric ? selectedFabric.name : undefined
                    )
                  }
                  className="w-full py-2.5 px-4 rounded-md bg-stone-900 text-white hover:bg-[#C5A059] hover:text-stone-950 text-xs font-semibold uppercase tracking-wider transition-all flex items-center justify-center gap-2"
                >
                  <Scissors className="w-3.5 h-3.5" />
                  <span>Inquire for Commission</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Fine Fabric Library Highlight */}
        <div className="mt-16 bg-stone-900 text-stone-100 rounded-lg p-8 sm:p-10 border border-stone-800 space-y-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-stone-800 pb-6">
            <div>
              <span className="text-xs uppercase tracking-widest text-[#C5A059] font-semibold block">
                Heritage Textile Collection
              </span>
              <h3 className="font-serif-title text-2xl sm:text-3xl font-normal text-white">
                Selected Wool, Silk & Velvet Fabrics
              </h3>
            </div>
            <Link
              to="/visualizer"
              className="px-4 py-2.5 rounded bg-[#C5A059] text-stone-950 font-semibold text-xs uppercase tracking-wider hover:bg-[#d6b066] transition-all flex items-center gap-2 shrink-0"
            >
              <Sparkles className="w-4 h-4 text-stone-950" />
              <span>Visualize in AI Generator</span>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            {/* Fabric List Buttons */}
            <div className="md:col-span-5 space-y-3">
              {fabrics.map((fab) => (
                <button
                  key={fab.id}
                  onClick={() => setSelectedFabric(fab)}
                  className={`w-full p-3.5 rounded-md text-left transition-all flex items-center justify-between border ${
                    selectedFabric?.id === fab.id
                      ? 'border-[#C5A059] bg-stone-800 text-white'
                      : 'border-stone-800 bg-stone-900/60 text-stone-300 hover:border-stone-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-6 h-6 rounded-full border border-stone-600 shrink-0 shadow-xs"
                      style={{ backgroundColor: fab.colorHex }}
                    />
                    <div>
                      <span className="text-xs font-semibold block text-stone-100">
                        {fab.name}
                      </span>
                      <span className="text-[11px] text-stone-400">
                        {fab.composition} • {fab.origin}
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-stone-800 text-[#C5A059] font-mono border border-stone-700">
                    {fab.priceTier}
                  </span>
                </button>
              ))}
            </div>

            {/* Selected Fabric Spotlight */}
            {selectedFabric && (
              <div className="md:col-span-7 bg-stone-950 p-6 rounded-lg border border-stone-800 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-center">
                  <div className="h-48 rounded overflow-hidden relative">
                    <img
                      src={selectedFabric.imageUrl}
                      alt={selectedFabric.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                    <div className="absolute bottom-3 left-3 text-xs text-white">
                      <span className="text-[#C5A059] font-semibold block">Origin</span>
                      {selectedFabric.origin}
                    </div>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div>
                      <span className="text-stone-400 block text-[10px] uppercase tracking-wider">
                        Fabric Name
                      </span>
                      <p className="text-base font-serif-title text-white">
                        {selectedFabric.name}
                      </p>
                    </div>

                    <div>
                      <span className="text-stone-400 block text-[10px] uppercase tracking-wider">
                        Composition
                      </span>
                      <p className="text-stone-200">{selectedFabric.composition}</p>
                    </div>

                    <div className="flex items-center gap-4">
                      <div>
                        <span className="text-stone-400 block text-[10px] uppercase tracking-wider">
                          Weave Pattern
                        </span>
                        <p className="text-stone-200 capitalize">{selectedFabric.pattern}</p>
                      </div>
                      <div>
                        <span className="text-stone-400 block text-[10px] uppercase tracking-wider">
                          Status
                        </span>
                        <p className="text-emerald-400 font-semibold">
                          {selectedFabric.inStock ? 'In Atelier Reserve' : 'Special Import'}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() =>
                        onSelectServiceForInquiry(
                          'Two-Piece Bespoke Suit',
                          selectedFabric.name
                        )
                      }
                      className="w-full py-2 bg-[#C5A059] text-stone-950 font-semibold rounded text-xs hover:bg-[#d6b066] transition-all flex items-center justify-center gap-1.5"
                    >
                      <span>Inquire With This Fabric</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Pricing Transparency Note */}
        <div className="bg-stone-200/50 rounded-md p-4 text-xs text-stone-700 flex items-start gap-3 border border-stone-300/60">
          <Info className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
          <p>
            <span className="font-semibold text-stone-900">Atelier Guarantee:</span> {shopSettings.pricingNote} Standard deposit is {shopSettings.depositPercentage}% at commission signing.
          </p>
        </div>
      </div>
    </section>
  );
};
