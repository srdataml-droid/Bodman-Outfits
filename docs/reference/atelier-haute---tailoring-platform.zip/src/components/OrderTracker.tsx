import React, { useState, useEffect } from 'react';
import { Order, OrderStatus } from '../types';
import {
  Search,
  CheckCircle2,
  Clock,
  Scissors,
  Calendar,
  AlertCircle,
  FileText,
  CreditCard,
  MapPin,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { apiClient } from '../lib/api-client';

interface OrderTrackerProps {
  initialSearchQuery?: string;
  onSearchOrders: (query: string) => Promise<Order[]>;
}

export const OrderTracker: React.FC<OrderTrackerProps> = ({
  initialSearchQuery = '',
  onSearchOrders,
}) => {
  const [query, setQuery] = useState(initialSearchQuery || 'ORD-2026-8832');
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [paystackVerification, setPaystackVerification] = useState<{
    verifying: boolean;
    verified?: boolean;
    message?: string;
    transaction?: any;
    order?: Order;
  } | null>(null);

  const stages: { key: OrderStatus; label: string; desc: string }[] = [
    { key: 'placed', label: 'Order Placed', desc: 'Consultation & deposit confirmed' },
    { key: 'confirmed', label: 'Confirmed', desc: 'Anatomical pattern drafted' },
    { key: 'fabric_cut', label: 'Fabric Cut', desc: 'Cloth & haircloth canvas prepared' },
    { key: 'in_production', label: 'In Production', desc: 'Basted fitting assembly in progress' },
    { key: 'fitting_required', label: 'Fitting Session', desc: 'Canvas trial adjustment required' },
    { key: 'ready', label: 'Ready for Pickup', desc: 'Final hand press & garment bag ready' },
    { key: 'delivered', label: 'Delivered', desc: 'Commission completed' },
  ];

  const getStageIndex = (status: OrderStatus) => {
    return stages.findIndex((s) => s.key === status);
  };

  const handleSearch = async (e?: React.FormEvent, searchQueryOverride?: string) => {
    if (e) e.preventDefault();
    const targetQuery = (searchQueryOverride || query).trim();
    if (!targetQuery) return;

    setLoading(true);
    setErrorMsg(null);
    setSearched(true);

    try {
      const results = await onSearchOrders(targetQuery);
      setOrders(results);
    } catch (err: any) {
      setErrorMsg(err.message || 'Error looking up order. Please verify your reference number.');
      setOrders([]);
    } finally {
      setLoading(false);
    }
  };

  // Perform initial search & handle Paystack callback verification on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('reference') || params.get('trxref');
    const isVerify = params.get('verify') === 'paystack' || params.has('trxref');

    if (ref && isVerify) {
      setQuery(ref);
      setPaystackVerification({ verifying: true });
      setLoading(true);

      apiClient
        .verifyPaystackPayment(ref)
        .then((res) => {
          setPaystackVerification({
            verifying: false,
            verified: res.verified,
            message: res.verified
              ? 'Payment verified via Paystack server.'
              : res.error || 'Payment verification failed.',
            transaction: res.transaction,
            order: res.order,
          });

          if (res.order) {
            setOrders([res.order]);
            setSearched(true);
          } else {
            handleSearch(undefined, ref);
          }
        })
        .catch((err) => {
          setPaystackVerification({
            verifying: false,
            verified: false,
            message: err.message || 'Failed to verify transaction with Paystack server.',
          });
          handleSearch(undefined, ref);
        })
        .finally(() => {
          setLoading(false);
        });
    } else {
      handleSearch();
    }
  }, []);


  return (
    <section className="py-16 bg-[#FAF9F6] text-stone-900 min-h-[70vh]">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-xs uppercase tracking-widest text-[#C5A059] font-semibold">
            Live Order Timeline
          </span>
          <h2 className="font-serif-title text-3xl sm:text-4xl font-normal text-stone-900">
            Track Your Bespoke Commission
          </h2>
          <p className="text-stone-600 text-sm font-light leading-relaxed">
            Enter your Order Reference Number (e.g., <code className="font-mono bg-stone-200 px-1.5 py-0.5 rounded text-xs">ORD-2026-8832</code>) or registered phone number to view real-time progress.
          </p>
        </div>

        {/* Search Input Box */}
        <form onSubmit={handleSearch} className="max-w-xl mx-auto flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g. ORD-2026-8832 or Phone Number"
              className="w-full pl-11 pr-4 py-3 bg-white border border-stone-300 rounded-md text-sm text-stone-900 placeholder-stone-400 focus:outline-none focus:border-[#C5A059] shadow-xs font-mono"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-3 rounded-md bg-stone-900 text-white font-semibold text-xs uppercase tracking-wider hover:bg-[#C5A059] hover:text-stone-950 transition-all shrink-0 flex items-center gap-2"
          >
            {loading ? 'Searching...' : 'Track Order'}
          </button>
        </form>

        {/* Search Quick Sample Buttons */}
        <div className="flex items-center justify-center gap-2 text-xs text-stone-500">
          <span>Try sample orders:</span>
          <button
            onClick={() => {
              setQuery('ORD-2026-8832');
              onSearchOrders('ORD-2026-8832').then(setOrders);
            }}
            className="text-[#C5A059] font-mono hover:underline"
          >
            ORD-2026-8832
          </button>
          <span>•</span>
          <button
            onClick={() => {
              setQuery('ORD-2026-9041');
              onSearchOrders('ORD-2026-9041').then(setOrders);
            }}
            className="text-[#C5A059] font-mono hover:underline"
          >
            ORD-2026-9041
          </button>
        </div>

        {/* Paystack Payment Verification Banner */}
        {paystackVerification && (
          <div
            className={`p-5 rounded-lg border shadow-xs space-y-3 max-w-3xl mx-auto transition-all ${
              paystackVerification.verifying
                ? 'bg-amber-50 border-amber-300 text-amber-900'
                : paystackVerification.verified
                ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                : 'bg-red-50 border-red-300 text-red-900'
            }`}
          >
            <div className="flex items-center justify-between border-b pb-2 border-stone-200/60">
              <div className="flex items-center gap-2 font-semibold text-sm">
                <CreditCard className="w-5 h-5 text-[#C5A059]" />
                <span>Paystack Direct Verification</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-[#C5A059] text-stone-950">
                  ⚡ TEST MODE
                </span>
              </div>
              {paystackVerification.transaction?.reference && (
                <span className="font-mono text-xs font-bold text-stone-700">
                  Ref: {paystackVerification.transaction.reference}
                </span>
              )}
            </div>

            {paystackVerification.verifying ? (
              <div className="flex items-center gap-2 text-xs font-medium py-1">
                <div className="w-4 h-4 border-2 border-amber-600 border-t-transparent rounded-full animate-spin" />
                <span>Contacting Paystack API to verify transaction reference... Please wait.</span>
              </div>
            ) : paystackVerification.verified ? (
              <div className="space-y-2 text-xs">
                <p className="font-medium text-emerald-900 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4.5 h-4.5 text-emerald-600 shrink-0" />
                  <span>
                    Payment verified successfully! Deposit confirmed and order status updated to <strong>CONFIRMED</strong>.
                  </span>
                </p>
                {paystackVerification.transaction && (
                  <div className="bg-white/90 p-3 rounded border border-emerald-200 grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] shadow-2xs">
                    <div>
                      <span className="text-stone-500 block">Amount Verified</span>
                      <span className="font-semibold text-stone-900 font-mono">
                        ₦{paystackVerification.transaction.amount?.toLocaleString()}
                      </span>
                    </div>
                    <div>
                      <span className="text-stone-500 block">Channel</span>
                      <span className="font-semibold text-stone-900 uppercase">
                        {paystackVerification.transaction.channel || 'Card'}
                      </span>
                    </div>
                    <div>
                      <span className="text-stone-500 block">Gateway Response</span>
                      <span className="font-semibold text-emerald-700">
                        {paystackVerification.transaction.gatewayResponse || 'Successful'}
                      </span>
                    </div>
                    <div>
                      <span className="text-stone-500 block">Verification Status</span>
                      <span className="font-semibold text-emerald-700 flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5" /> 200 Verified
                      </span>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-xs text-red-800 font-medium">
                {paystackVerification.message}
              </p>
            )}
          </div>
        )}


        {/* Error message */}
        {errorMsg && (
          <div className="bg-red-50 border border-red-200 text-red-800 p-4 rounded-md text-xs text-center">
            {errorMsg}
          </div>
        )}

        {/* Search Results Display */}
        {searched && !loading && (
          <div className="space-y-8">
            {orders && orders.length > 0 ? (
              orders.map((order) => {
                const currentStageIdx = getStageIndex(order.status);
                const progressPct = Math.round(
                  ((currentStageIdx + 1) / stages.length) * 100
                );

                return (
                  <div
                    key={order.id}
                    className="bg-white border border-stone-200 rounded-lg p-6 sm:p-8 space-y-8 shadow-xs"
                  >
                    {/* Top Order Overview Banner */}
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-100 pb-6">
                      <div>
                        <div className="flex items-center gap-3">
                          <span className="font-mono text-xl font-bold text-stone-900">
                            {order.id}
                          </span>
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-[#C5A059]/15 text-[#8A6A27] border border-[#C5A059]/30 capitalize">
                            {order.status.replace('_', ' ')}
                          </span>
                        </div>
                        <p className="text-xs text-stone-500 mt-1">
                          Client: <span className="font-semibold text-stone-800">{order.customerName}</span> • Commissioned on {new Date(order.createdAt).toLocaleDateString()}
                        </p>
                      </div>

                      <div className="flex items-center gap-6 text-xs text-stone-700 bg-stone-50 p-3 rounded border border-stone-200">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-[#C5A059]" />
                          <div>
                            <span className="text-[10px] uppercase text-stone-400 block font-semibold">
                              Completion Target
                            </span>
                            <span className="font-semibold text-stone-900">
                              {order.estimatedCompletionDate}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 border-l border-stone-200 pl-4">
                          <CreditCard className="w-4 h-4 text-[#C5A059]" />
                          <div>
                            <span className="text-[10px] uppercase text-stone-400 block font-semibold">
                              Payment Status
                            </span>
                            <span className="font-semibold capitalize text-stone-900">
                              {order.paymentStatus.replace('_', ' ')}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Stage Progress Bar */}
                    <div className="space-y-4">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-semibold uppercase tracking-wider text-stone-700">
                          Tailoring Stage Progress
                        </span>
                        <span className="font-mono font-bold text-[#C5A059]">
                          {progressPct}% Complete
                        </span>
                      </div>

                      <div className="w-full bg-stone-100 rounded-full h-2.5 overflow-hidden border border-stone-200">
                        <div
                          className="bg-gradient-to-r from-stone-900 to-[#C5A059] h-full transition-all duration-500 rounded-full"
                          style={{ width: `${progressPct}%` }}
                        />
                      </div>

                      {/* Timeline Stepper */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 pt-2">
                        {stages.map((stage, idx) => {
                          const isDone = idx <= currentStageIdx;
                          const isCurrent = idx === currentStageIdx;

                          return (
                            <div
                              key={stage.key}
                              className={`p-2.5 rounded border text-left space-y-1 transition-all ${
                                isCurrent
                                  ? 'bg-stone-900 text-white border-stone-900 ring-2 ring-[#C5A059]'
                                  : isDone
                                  ? 'bg-stone-100 text-stone-800 border-stone-300'
                                  : 'bg-stone-50/50 text-stone-400 border-stone-200'
                              }`}
                            >
                              <div className="flex items-center justify-between text-[10px]">
                                <span className="font-mono font-bold">0{idx + 1}</span>
                                {isDone && <CheckCircle2 className={`w-3 h-3 ${isCurrent ? 'text-[#C5A059]' : 'text-emerald-600'}`} />}
                              </div>
                              <p className="text-[11px] font-semibold leading-snug">
                                {stage.label}
                              </p>
                              <p className="text-[10px] line-clamp-2 leading-tight opacity-80">
                                {stage.desc}
                              </p>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Fitting Session Notice Box if status is fitting_required or in_production */}
                    {order.fittingDate && (
                      <div className="bg-[#C5A059]/10 border border-[#C5A059]/30 rounded-md p-4 text-xs text-stone-800 flex items-start justify-between gap-4">
                        <div className="flex items-start gap-3">
                          <Scissors className="w-5 h-5 text-[#C5A059] shrink-0 mt-0.5" />
                          <div>
                            <span className="font-semibold text-stone-900 block text-sm">
                              Scheduled Canvas Fitting Session
                            </span>
                            <p className="text-stone-700 mt-0.5">
                              {order.fittingDate} at our Victoria Island Atelier.
                            </p>
                          </div>
                        </div>
                        <span className="text-[11px] font-semibold text-[#8A6A27] bg-[#C5A059]/20 px-2.5 py-1 rounded shrink-0">
                          Fitting Confirmed
                        </span>
                      </div>
                    )}

                    {/* Specs & History Grid */}
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-2 border-t border-stone-100">
                      {/* Specifications Summary */}
                      <div className="lg:col-span-6 space-y-3 bg-stone-50 p-4 rounded border border-stone-200 text-xs">
                        <span className="font-semibold text-stone-900 uppercase tracking-wider block">
                          Commission Specifications
                        </span>
                        <div className="space-y-1.5 text-stone-700">
                          <div className="flex justify-between">
                            <span className="text-stone-500">Service:</span>
                            <span className="font-semibold text-stone-900">{order.serviceTitle}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-stone-500">Cloth Selected:</span>
                            <span className="font-semibold text-stone-900">{order.fabricName}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-stone-500">Total Price:</span>
                            <span className="font-mono font-semibold">₦{order.totalPrice.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-stone-500">Deposit Paid:</span>
                            <span className="font-mono font-semibold text-emerald-700">₦{order.depositAmount.toLocaleString()}</span>
                          </div>
                          {order.notes && (
                            <div className="pt-2 border-t border-stone-200">
                              <span className="text-stone-500 block">Atelier Notes:</span>
                              <p className="italic text-stone-800">{order.notes}</p>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Tailor's Audit Trail */}
                      <div className="lg:col-span-6 space-y-3 bg-stone-50 p-4 rounded border border-stone-200 text-xs">
                        <span className="font-semibold text-stone-900 uppercase tracking-wider block">
                          Tailor's Live Log History
                        </span>
                        <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                          {order.history.map((log, idx) => (
                            <div key={idx} className="flex items-start gap-2 text-stone-700 border-b border-stone-200/60 pb-1.5">
                              <Clock className="w-3.5 h-3.5 text-[#C5A059] shrink-0 mt-0.5" />
                              <div className="flex-1">
                                <div className="flex justify-between items-center">
                                  <span className="font-semibold text-stone-900 capitalize">
                                    {log.status.replace('_', ' ')}
                                  </span>
                                  <span className="text-[10px] text-stone-400 font-mono">
                                    {new Date(log.timestamp).toLocaleDateString()}
                                  </span>
                                </div>
                                {log.note && <p className="text-[11px] text-stone-600">{log.note}</p>}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="bg-white border border-stone-200 rounded-lg p-8 text-center space-y-3">
                <AlertCircle className="w-8 h-8 text-amber-500 mx-auto" />
                <h3 className="font-serif-title text-xl text-stone-900">
                  No Order Found for "{query}"
                </h3>
                <p className="text-xs text-stone-600 max-w-md mx-auto">
                  Please verify your reference number or phone number. You can also contact our concierge directly if you recently submitted an order.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
};
