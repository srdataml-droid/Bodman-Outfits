import React, { useState } from 'react';
import {
  Ruler,
  CheckCircle2,
  Info,
  ArrowRight,
  Scissors,
  Save,
} from 'lucide-react';
import { SizeFitResult } from '../types';

interface SizeFitAdvisorProps {
  onSaveMeasurementToDatabase?: (data: any) => void;
  onProceedToInquiryWithFit?: (fitSummary: string) => void;
}

export const SizeFitAdvisor: React.FC<SizeFitAdvisorProps> = ({
  onSaveMeasurementToDatabase,
  onProceedToInquiryWithFit,
}) => {
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [chest, setChest] = useState<number>(40);
  const [waist, setWaist] = useState<number>(34);
  const [shoulder, setShoulder] = useState<number>(18.5);
  const [sleeve, setSleeve] = useState<number>(25.5);
  const [heightCm, setHeightCm] = useState<number>(180);
  const [preferredFit, setPreferredFit] = useState<'slim' | 'classic' | 'relaxed'>('slim');

  const calculateFit = (): SizeFitResult => {
    // European sizing: standard chest 40 = EU 50 / US 40
    let sizeNumber = Math.round(chest);
    if (sizeNumber % 2 !== 0) sizeNumber += 1; // Round to even jacket size

    // Length designation based on height
    let length = 'R';
    if (heightCm < 172) length = 'S';
    else if (heightCm > 184) length = 'L';

    const recommendedJacketSize = `${sizeNumber}${length}`;
    const recommendedTrouserWaist = Math.round(waist);
    const dropDiff = chest - waist;

    let fitCategory: 'Athletic V-Drop' | 'Standard European Fit' | 'Comfort Executive Fit' =
      'Standard European Fit';
    const fitNotes: string[] = [];

    if (dropDiff >= 8) {
      fitCategory = 'Athletic V-Drop';
      fitNotes.push(`Pronounced V-taper (${dropDiff}" drop). Waist suppression required on jacket side seams.`);
      fitNotes.push('Recommend soft natural shoulder padding to balance muscular chest.');
    } else if (dropDiff >= 5 && dropDiff <= 7) {
      fitCategory = 'Standard European Fit';
      fitNotes.push(`Balanced Drop ${dropDiff} proportion. Standard canvas baseline will fit with minimal side adjustment.`);
      fitNotes.push('Clean chest drape with moderate waist suppression.');
    } else {
      fitCategory = 'Comfort Executive Fit';
      fitNotes.push('Comfort midsection stance. Requires clean front canvas drape without pulling across buttons.');
      fitNotes.push('Recommend trousers cut with forward double pleats for maximum seated comfort.');
    }

    if (preferredFit === 'slim') {
      fitNotes.push('Slim stance requested: High armholes and tapered trouser leg opening (14.5").');
    } else if (preferredFit === 'classic') {
      fitNotes.push('Classic stance requested: Traditional Savile Row silhouette with comfortable mobility.');
    } else {
      fitNotes.push('Relaxed stance requested: Generous ease throughout shoulder blades and thigh line.');
    }

    return {
      recommendedJacketSize,
      recommendedTrouserWaist,
      dropDiff,
      fitCategory,
      fitNotes,
      recommendedFitType: preferredFit,
    };
  };

  const result = calculateFit();
  const [savedMsg, setSavedMsg] = useState(false);

  const handleSaveToProfile = () => {
    if (!customerName || !phone) {
      alert('Please provide customer name and phone number to preserve your measurement profile.');
      return;
    }

    if (onSaveMeasurementToDatabase) {
      onSaveMeasurementToDatabase({
        customerName,
        phone,
        chest,
        waist,
        shoulder,
        sleeve,
        neck: Math.round(chest * 0.4),
        hip: Math.round(waist + 6),
        inseam: Math.round(heightCm * 0.177),
        heightCm,
        preferredFit,
        postureNotes: `${result.fitCategory} (${result.recommendedJacketSize}). Drop: ${result.dropDiff}". Notes: ${result.fitNotes.join(' ')}`,
      });
      setSavedMsg(true);
      setTimeout(() => setSavedMsg(false), 4000);
    }
  };

  return (
    <section className="py-16 bg-[#FAF9F6] text-stone-900">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-xs uppercase tracking-widest text-[#C5A059] font-semibold">
            Deterministic Fit Matrix
          </span>
          <h2 className="font-serif-title text-3xl sm:text-4xl font-normal text-stone-900">
            Rules-Based Size & Anatomical Fit Calculator
          </h2>
          <p className="text-stone-600 text-sm sm:text-base font-light leading-relaxed">
            Enter key body measurements to compute your baseline jacket size, drop ratio, and tailor's canvas adjustment notes before your baseline fitting.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Measurement Input Form */}
          <div className="lg:col-span-6 bg-white border border-stone-200 rounded-lg p-6 sm:p-8 space-y-6 shadow-xs">
            <h3 className="font-serif-title text-xl text-stone-900 border-b border-stone-100 pb-3 flex items-center gap-2">
              <Ruler className="w-5 h-5 text-[#C5A059]" />
              <span>Anatomical Measurements</span>
            </h3>

            {/* Optional Name & Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs uppercase tracking-wider text-stone-500 font-semibold block">
                  Full Name (Optional)
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Adebayo Ogunlesi"
                  className="w-full bg-stone-50 border border-stone-300 rounded p-2.5 text-xs text-stone-900 focus:outline-none focus:border-[#C5A059]"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs uppercase tracking-wider text-stone-500 font-semibold block">
                  Phone Number
                </label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. +234 802 333 4455"
                  className="w-full bg-stone-50 border border-stone-300 rounded p-2.5 text-xs text-stone-900 focus:outline-none focus:border-[#C5A059]"
                />
              </div>
            </div>

            {/* Sliders for Chest & Waist */}
            <div className="space-y-5 pt-2 border-t border-stone-100">
              {/* Chest Circumference */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-stone-800">Chest Circumference:</span>
                  <span className="font-mono font-bold text-[#C5A059]">{chest}"</span>
                </div>
                <input
                  type="range"
                  min="34"
                  max="54"
                  step="0.5"
                  value={chest}
                  onChange={(e) => setChest(parseFloat(e.target.value))}
                  className="w-full accent-[#C5A059]"
                />
              </div>

              {/* Waist Circumference */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-stone-800">Natural Waist Circumference:</span>
                  <span className="font-mono font-bold text-[#C5A059]">{waist}"</span>
                </div>
                <input
                  type="range"
                  min="28"
                  max="48"
                  step="0.5"
                  value={waist}
                  onChange={(e) => setWaist(parseFloat(e.target.value))}
                  className="w-full accent-[#C5A059]"
                />
              </div>

              {/* Shoulder & Height */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-stone-800 block">
                    Shoulder Width Across Back (in)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={shoulder}
                    onChange={(e) => setShoulder(parseFloat(e.target.value))}
                    className="w-full bg-stone-50 border border-stone-300 rounded p-2 text-xs font-mono font-semibold text-stone-900"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-stone-800 block">
                    Height (cm)
                  </label>
                  <input
                    type="number"
                    value={heightCm}
                    onChange={(e) => setHeightCm(parseInt(e.target.value))}
                    className="w-full bg-stone-50 border border-stone-300 rounded p-2 text-xs font-mono font-semibold text-stone-900"
                  />
                </div>
              </div>

              {/* Preferred Fit Stance */}
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-wider text-stone-500 font-semibold block">
                  Preferred Silhouette Stance
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['slim', 'classic', 'relaxed'] as const).map((fit) => (
                    <button
                      key={fit}
                      onClick={() => setPreferredFit(fit)}
                      className={`py-2 px-3 rounded text-xs font-medium uppercase tracking-wider border transition-all ${
                        preferredFit === fit
                          ? 'bg-stone-900 text-white border-stone-900'
                          : 'bg-stone-100 text-stone-700 border-stone-200 hover:bg-stone-200'
                      }`}
                    >
                      {fit}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Save to Profile Button */}
            <div className="pt-2">
              <button
                onClick={handleSaveToProfile}
                className="w-full py-3 rounded bg-stone-900 text-white font-semibold text-xs uppercase tracking-wider hover:bg-[#C5A059] hover:text-stone-950 transition-all flex items-center justify-center gap-2"
              >
                <Save className="w-4 h-4" />
                <span>Save Body Profile to Atelier Database</span>
              </button>
              {savedMsg && (
                <p className="text-xs text-emerald-700 text-center font-medium mt-2">
                  ✓ Profile saved! Master tailors can access this profile for your commissions.
                </p>
              )}
            </div>
          </div>

          {/* Results Output Column */}
          <div className="lg:col-span-6 bg-stone-900 text-stone-100 border border-stone-800 rounded-lg p-6 sm:p-8 space-y-6 shadow-xl">
            <div className="flex items-center justify-between border-b border-stone-800 pb-4">
              <h3 className="font-serif-title text-xl text-white flex items-center gap-2">
                <Scissors className="w-5 h-5 text-[#C5A059]" />
                <span>Fit Recommendation Output</span>
              </h3>
              <span className="text-xs font-mono text-[#C5A059] bg-[#C5A059]/15 px-2.5 py-1 rounded border border-[#C5A059]/30">
                Rule Matrix v2.4
              </span>
            </div>

            {/* Calculated Metrics Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-stone-950 p-4 rounded border border-stone-800 space-y-1">
                <span className="text-[10px] uppercase tracking-wider text-stone-400 block font-semibold">
                  Recommended Jacket Size
                </span>
                <p className="font-serif-title text-3xl font-bold text-[#C5A059]">
                  {result.recommendedJacketSize}
                </p>
                <p className="text-[11px] text-stone-400">
                  EU Size {Math.round(chest) % 2 === 0 ? Math.round(chest) : Math.round(chest) + 1}
                </p>
              </div>

              <div className="bg-stone-950 p-4 rounded border border-stone-800 space-y-1">
                <span className="text-[10px] uppercase tracking-wider text-stone-400 block font-semibold">
                  Trouser Waist Cut
                </span>
                <p className="font-serif-title text-3xl font-bold text-[#C5A059]">
                  {result.recommendedTrouserWaist}"
                </p>
                <p className="text-[11px] text-stone-400">Includes 1" comfort ease</p>
              </div>
            </div>

            {/* Drop Ratio & Classification */}
            <div className="bg-stone-950 p-4 rounded border border-stone-800 space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-xs text-stone-400 uppercase tracking-wider font-semibold">
                  Anatomical Stance Classification
                </span>
                <span className="text-xs font-bold text-white bg-stone-800 px-2 py-0.5 rounded">
                  Drop {result.dropDiff}" Ratio
                </span>
              </div>
              <p className="text-base font-semibold text-white">{result.fitCategory}</p>
            </div>

            {/* Tailor's Baseline Notes */}
            <div className="space-y-3 pt-2">
              <span className="text-xs uppercase tracking-wider text-stone-400 font-semibold block">
                Tailor's Canvas Adjustment Directives
              </span>
              <ul className="space-y-2 text-xs text-stone-300">
                {result.fitNotes.map((note, idx) => (
                  <li key={idx} className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                    <span>{note}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Proceed to Commission */}
            {onProceedToInquiryWithFit && (
              <div className="pt-4 border-t border-stone-800">
                <button
                  onClick={() =>
                    onProceedToInquiryWithFit(
                      `Recommended Size: ${result.recommendedJacketSize}, Trouser Waist: ${result.recommendedTrouserWaist}". Drop: ${result.dropDiff}". Stance: ${result.fitCategory}.`
                    )
                  }
                  className="w-full py-3 bg-[#C5A059] text-stone-950 font-semibold rounded text-xs uppercase tracking-wider hover:bg-[#d6b066] transition-all flex items-center justify-center gap-2"
                >
                  <span>Inquire Commission with These Fit Metrics</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Note on Trust Signal #1 */}
        <div className="bg-white p-5 rounded-lg border border-stone-200 text-xs text-stone-700 flex items-start gap-3 shadow-xs">
          <Info className="w-5 h-5 text-[#C5A059] shrink-0 mt-0.5" />
          <p>
            <span className="font-semibold text-stone-900">Why Saved Measurements Build Trust:</span> Unlike off-the-rack fashion, your anatomical profile is archived in our secure Atelier database. When you commission a new suit or traditional attire next month or next year, you will never re-explain your fit parameters.
          </p>
        </div>
      </div>
    </section>
  );
};
