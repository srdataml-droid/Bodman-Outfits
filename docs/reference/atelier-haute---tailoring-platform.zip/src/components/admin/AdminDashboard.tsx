import React, { useState } from 'react';
import {
  FabricOption,
  GuestInquiry,
  MeasurementProfile,
  Order,
  OrderStatus,
  PaymentStatus,
  ServiceItem,
  ShopSettings,
  Subscriber,
} from '../../types';
import {
  Scissors,
  ShoppingBag,
  Ruler,
  Users,
  Settings,
  Plus,
  Search,
  CheckCircle2,
  Clock,
  Edit,
  Save,
  ArrowRight,
  ShieldCheck,
  Mail,
  Download,
} from 'lucide-react';

interface AdminDashboardProps {
  orders: Order[];
  measurements: MeasurementProfile[];
  services: ServiceItem[];
  fabrics: FabricOption[];
  inquiries: GuestInquiry[];
  subscribers: Subscriber[];
  shopSettings: ShopSettings;
  onUpdateOrderStatus: (id: string, status: OrderStatus, note?: string, paymentStatus?: PaymentStatus, fittingDate?: string) => Promise<void>;
  onCreateOrder: (orderData: any) => Promise<void>;
  onCreateMeasurement: (m: any) => Promise<void>;
  onUpdateMeasurement: (id: string, m: any) => Promise<void>;
  onAddService: (s: any) => Promise<void>;
  onAddFabric: (f: any) => Promise<void>;
  onUpdateInquiryStatus: (id: string, status: string) => Promise<void>;
  onUpdateShopSettings: (settings: any) => Promise<void>;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  orders,
  measurements,
  services,
  fabrics,
  inquiries,
  subscribers,
  shopSettings,
  onUpdateOrderStatus,
  onCreateOrder,
  onCreateMeasurement,
  onUpdateMeasurement,
  onAddService,
  onAddFabric,
  onUpdateInquiryStatus,
  onUpdateShopSettings,
}) => {
  const [activeAdminTab, setActiveAdminTab] = useState<
    'orders' | 'measurements' | 'catalog' | 'inquiries' | 'subscribers' | 'settings'
  >('orders');

  // Search filters
  const [orderFilter, setOrderFilter] = useState('');
  const [measurementFilter, setMeasurementFilter] = useState('');

  // Modals / Form toggles
  const [showNewOrderModal, setShowNewOrderModal] = useState(false);
  const [showNewMeasurementModal, setShowNewMeasurementModal] = useState(false);
  const [editingMeasurement, setEditingMeasurement] = useState<MeasurementProfile | null>(null);

  // New Order State
  const [newOrderCustomer, setNewOrderCustomer] = useState('');
  const [newOrderPhone, setNewOrderPhone] = useState('');
  const [newOrderEmail, setNewOrderEmail] = useState('');
  const [newOrderService, setNewOrderService] = useState(services[0]?.title || 'Two-Piece Bespoke Suit');
  const [newOrderFabric, setNewOrderFabric] = useState(fabrics[0]?.name || 'Super 130s Navy Herringbone');
  const [newOrderPrice, setNewOrderPrice] = useState(380000);
  const [newOrderDeposit, setNewOrderDeposit] = useState(190000);
  const [newOrderEstDate, setNewOrderEstDate] = useState('2026-08-15');

  // New Measurement State
  const [mName, setMName] = useState('');
  const [mPhone, setMPhone] = useState('');
  const [mChest, setMChest] = useState(40);
  const [mWaist, setMWaist] = useState(34);
  const [mShoulder, setMShoulder] = useState(18.5);
  const [mSleeve, setMSleeve] = useState(25.5);
  const [mNeck, setMNeck] = useState(16.5);
  const [mHip, setMHip] = useState(40);
  const [mInseam, setMInseam] = useState(32);
  const [mHeight, setMHeight] = useState(180);
  const [mFit, setMFit] = useState<'slim' | 'classic' | 'relaxed'>('slim');
  const [mNotes, setMNotes] = useState('');

  // Settings State
  const [settingsForm, setSettingsForm] = useState<ShopSettings>({ ...shopSettings });
  const [settingsSavedMsg, setSettingsSavedMsg] = useState(false);

  // Status edit inline
  const [editingOrderId, setEditingOrderId] = useState<string | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<OrderStatus>('placed');
  const [selectedPayment, setSelectedPayment] = useState<PaymentStatus>('deposit_paid');
  const [statusNote, setStatusNote] = useState('');
  const [fittingDateInput, setFittingDateInput] = useState('');

  const filteredOrders = orders.filter(
    (o) =>
      o.id.toLowerCase().includes(orderFilter.toLowerCase()) ||
      o.customerName.toLowerCase().includes(orderFilter.toLowerCase()) ||
      o.phone.includes(orderFilter)
  );

  const filteredMeasurements = measurements.filter(
    (m) =>
      m.customerName.toLowerCase().includes(measurementFilter.toLowerCase()) ||
      m.phone.includes(measurementFilter)
  );

  // Handle Order Create
  const handleCreateOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onCreateOrder({
      customerName: newOrderCustomer,
      phone: newOrderPhone,
      email: newOrderEmail,
      serviceTitle: newOrderService,
      fabricName: newOrderFabric,
      totalPrice: newOrderPrice,
      depositAmount: newOrderDeposit,
      estimatedCompletionDate: newOrderEstDate,
      status: 'placed',
      paymentStatus: newOrderDeposit >= newOrderPrice ? 'paid_in_full' : 'deposit_paid',
    });
    setShowNewOrderModal(false);
    setNewOrderCustomer('');
    setNewOrderPhone('');
  };

  // Handle Measurement Create / Edit
  const handleMeasurementSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingMeasurement) {
      await onUpdateMeasurement(editingMeasurement.id, {
        customerName: mName,
        phone: mPhone,
        chest: mChest,
        waist: mWaist,
        shoulder: mShoulder,
        sleeve: mSleeve,
        neck: mNeck,
        hip: mHip,
        inseam: mInseam,
        heightCm: mHeight,
        preferredFit: mFit,
        postureNotes: mNotes,
      });
      setEditingMeasurement(null);
    } else {
      await onCreateMeasurement({
        customerName: mName,
        phone: mPhone,
        chest: mChest,
        waist: mWaist,
        shoulder: mShoulder,
        sleeve: mSleeve,
        neck: mNeck,
        hip: mHip,
        inseam: mInseam,
        heightCm: mHeight,
        preferredFit: mFit,
        postureNotes: mNotes,
      });
    }
    setShowNewMeasurementModal(false);
  };

  // Convert Inquiry to Order in 1 click
  const handleConvertInquiry = async (inquiry: GuestInquiry) => {
    await onCreateOrder({
      customerName: inquiry.customerName,
      phone: inquiry.phone,
      email: inquiry.email,
      serviceTitle: inquiry.serviceRequested || 'Two-Piece Bespoke Suit',
      fabricName: inquiry.fabricPreference || 'Super 130s Navy Herringbone',
      totalPrice: 380000,
      depositAmount: 190000,
      estimatedCompletionDate: '2026-08-15',
      fittingDate: inquiry.preferredFittingDate || 'To be scheduled',
      notes: `Converted from guest inquiry ${inquiry.id}. ${inquiry.message}`,
      status: 'confirmed',
      paymentStatus: 'deposit_paid',
    });
    await onUpdateInquiryStatus(inquiry.id, 'converted');
    alert(`Inquiry ${inquiry.id} converted into active order for ${inquiry.customerName}!`);
  };

  // Save Shop Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    await onUpdateShopSettings(settingsForm);
    setSettingsSavedMsg(true);
    setTimeout(() => setSettingsSavedMsg(false), 3000);
  };

  return (
    <section className="py-10 bg-[#1C1917] text-stone-100 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-800 pb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded bg-[#C5A059] text-stone-950 flex items-center justify-center font-bold shadow-md">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-serif-title text-2xl font-normal text-white">
                  Atelier Master Dashboard
                </h2>
                <span className="px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/30">
                  ⚡ DEMO API MODE
                </span>
              </div>
              <p className="text-xs text-stone-400">
                Data access via <code className="text-[#C5A059] font-mono">apiClient</code> • Single-Business Management Portal • {shopSettings.shopName}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <span className="px-3 py-1 rounded bg-stone-900 border border-stone-800 text-stone-300 font-mono">
              Orders: <strong className="text-white">{orders.length}</strong>
            </span>
            <span className="px-3 py-1 rounded bg-stone-900 border border-stone-800 text-stone-300 font-mono">
              Inquiries: <strong className="text-[#C5A059]">{inquiries.filter((i) => i.status === 'new').length} New</strong>
            </span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-stone-800 pb-3 overflow-x-auto text-xs font-medium uppercase tracking-wider">
          <button
            onClick={() => setActiveAdminTab('orders')}
            className={`px-4 py-2 rounded-md flex items-center gap-2 transition-all ${
              activeAdminTab === 'orders'
                ? 'bg-[#C5A059] text-stone-950 font-bold'
                : 'text-stone-400 hover:text-white hover:bg-stone-900'
            }`}
          >
            <Scissors className="w-4 h-4" />
            <span>Orders ({orders.length})</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('measurements')}
            className={`px-4 py-2 rounded-md flex items-center gap-2 transition-all ${
              activeAdminTab === 'measurements'
                ? 'bg-[#C5A059] text-stone-950 font-bold'
                : 'text-stone-400 hover:text-white hover:bg-stone-900'
            }`}
          >
            <Ruler className="w-4 h-4" />
            <span>Measurements ({measurements.length})</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('inquiries')}
            className={`px-4 py-2 rounded-md flex items-center gap-2 transition-all ${
              activeAdminTab === 'inquiries'
                ? 'bg-[#C5A059] text-stone-950 font-bold'
                : 'text-stone-400 hover:text-white hover:bg-stone-900'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Inquiries ({inquiries.length})</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('catalog')}
            className={`px-4 py-2 rounded-md flex items-center gap-2 transition-all ${
              activeAdminTab === 'catalog'
                ? 'bg-[#C5A059] text-stone-950 font-bold'
                : 'text-stone-400 hover:text-white hover:bg-stone-900'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Services & Fabrics</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('subscribers')}
            className={`px-4 py-2 rounded-md flex items-center gap-2 transition-all ${
              activeAdminTab === 'subscribers'
                ? 'bg-[#C5A059] text-stone-950 font-bold'
                : 'text-stone-400 hover:text-white hover:bg-stone-900'
            }`}
          >
            <Mail className="w-4 h-4" />
            <span>Subscribers ({subscribers.length})</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('settings')}
            className={`px-4 py-2 rounded-md flex items-center gap-2 transition-all ${
              activeAdminTab === 'settings'
                ? 'bg-[#C5A059] text-stone-950 font-bold'
                : 'text-stone-400 hover:text-white hover:bg-stone-900'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Atelier Settings</span>
          </button>
        </div>

        {/* ------------------- TAB 1: ORDERS ------------------- */}
        {activeAdminTab === 'orders' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="relative flex-1 w-full sm:w-auto max-w-md">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-500" />
                <input
                  type="text"
                  value={orderFilter}
                  onChange={(e) => setOrderFilter(e.target.value)}
                  placeholder="Search orders by client name, ID or phone..."
                  className="w-full pl-9 pr-4 py-2.5 bg-stone-900 border border-stone-800 rounded text-xs text-white placeholder-stone-500 focus:outline-none focus:border-[#C5A059]"
                />
              </div>

              <button
                onClick={() => setShowNewOrderModal(true)}
                className="px-4 py-2.5 rounded bg-[#C5A059] text-stone-950 font-bold text-xs uppercase tracking-wider hover:bg-[#d6b066] transition-all flex items-center gap-2 shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Create New Order</span>
              </button>
            </div>

            {/* Orders List Table / Cards */}
            <div className="space-y-4">
              {filteredOrders.map((order) => (
                <div
                  key={order.id}
                  className="bg-stone-900 border border-stone-800 rounded-lg p-5 space-y-4 text-xs"
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-800 pb-4">
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="font-mono font-bold text-base text-white">{order.id}</span>
                        <span className="px-2.5 py-0.5 rounded text-[11px] font-semibold bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/30 capitalize">
                          {order.status.replace('_', ' ')}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[10px] bg-stone-800 text-stone-300 font-mono capitalize">
                          {order.paymentStatus.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-stone-400 mt-1">
                        Client: <strong className="text-stone-200">{order.customerName}</strong> ({order.phone}) • {order.serviceTitle} in {order.fabricName}
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="font-mono font-bold text-sm text-emerald-400">
                        ₦{order.totalPrice.toLocaleString()} (Deposit: ₦{order.depositAmount.toLocaleString()})
                      </span>
                      <button
                        onClick={() => {
                          if (editingOrderId === order.id) {
                            setEditingOrderId(null);
                          } else {
                            setEditingOrderId(order.id);
                            setSelectedStatus(order.status);
                            setSelectedPayment(order.paymentStatus);
                            setFittingDateInput(order.fittingDate || '');
                          }
                        }}
                        className="px-3 py-1.5 rounded bg-stone-800 hover:bg-stone-700 text-stone-200 font-semibold border border-stone-700 flex items-center gap-1.5"
                      >
                        <Edit className="w-3.5 h-3.5 text-[#C5A059]" />
                        <span>Update Status</span>
                      </button>
                    </div>
                  </div>

                  {/* Inline Status Edit Drawer */}
                  {editingOrderId === order.id && (
                    <div className="bg-stone-950 p-4 rounded border border-stone-800 space-y-4 animate-in fade-in">
                      <h4 className="font-semibold text-white text-xs">
                        Update Order {order.id} Tailoring Stage & Schedule
                      </h4>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="text-[10px] uppercase text-stone-400 block font-semibold mb-1">
                            Tailoring Stage
                          </label>
                          <select
                            value={selectedStatus}
                            onChange={(e) => setSelectedStatus(e.target.value as OrderStatus)}
                            className="w-full bg-stone-900 border border-stone-700 rounded p-2 text-xs text-stone-100"
                          >
                            <option value="placed">1. Order Placed</option>
                            <option value="confirmed">2. Confirmed</option>
                            <option value="fabric_cut">3. Fabric Cut</option>
                            <option value="in_production">4. In Production</option>
                            <option value="fitting_required">5. Fitting Session Required</option>
                            <option value="ready">6. Ready for Pickup</option>
                            <option value="delivered">7. Delivered</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-[10px] uppercase text-stone-400 block font-semibold mb-1">
                            Payment Status
                          </label>
                          <select
                            value={selectedPayment}
                            onChange={(e) => setSelectedPayment(e.target.value as PaymentStatus)}
                            className="w-full bg-stone-900 border border-stone-700 rounded p-2 text-xs text-stone-100"
                          >
                            <option value="unpaid">Unpaid</option>
                            <option value="deposit_paid">50% Deposit Paid</option>
                            <option value="paid_in_full">Paid in Full</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-[10px] uppercase text-stone-400 block font-semibold mb-1">
                            Fitting Date Note
                          </label>
                          <input
                            type="text"
                            value={fittingDateInput}
                            onChange={(e) => setFittingDateInput(e.target.value)}
                            placeholder="e.g. 2026-08-01 at 11:00 AM"
                            className="w-full bg-stone-900 border border-stone-700 rounded p-2 text-xs text-stone-100"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] uppercase text-stone-400 block font-semibold mb-1">
                          Tailor's Audit Note
                        </label>
                        <input
                          type="text"
                          value={statusNote}
                          onChange={(e) => setStatusNote(e.target.value)}
                          placeholder="e.g. Canvas baseline fitted, lapel pitch adjusted."
                          className="w-full bg-stone-900 border border-stone-700 rounded p-2 text-xs text-stone-100"
                        />
                      </div>

                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => setEditingOrderId(null)}
                          className="px-3 py-1.5 rounded bg-stone-800 text-stone-300 text-xs"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={async () => {
                            await onUpdateOrderStatus(
                              order.id,
                              selectedStatus,
                              statusNote,
                              selectedPayment,
                              fittingDateInput
                            );
                            setEditingOrderId(null);
                            setStatusNote('');
                          }}
                          className="px-4 py-1.5 rounded bg-[#C5A059] text-stone-950 font-bold text-xs"
                        >
                          Save Update
                        </button>
                      </div>
                    </div>
                  )}

                  {/* History Log Snippet */}
                  <div className="text-[11px] text-stone-400 flex items-center justify-between">
                    <span>Est. Target: <strong>{order.estimatedCompletionDate}</strong></span>
                    <span>Fitting: <strong>{order.fittingDate || 'Pending'}</strong></span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ------------------- TAB 2: MEASUREMENTS ------------------- */}
        {activeAdminTab === 'measurements' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="relative flex-1 w-full sm:w-auto max-w-md">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-500" />
                <input
                  type="text"
                  value={measurementFilter}
                  onChange={(e) => setMeasurementFilter(e.target.value)}
                  placeholder="Search measurements by client name or phone..."
                  className="w-full pl-9 pr-4 py-2.5 bg-stone-900 border border-stone-800 rounded text-xs text-white placeholder-stone-500 focus:outline-none focus:border-[#C5A059]"
                />
              </div>

              <button
                onClick={() => {
                  setEditingMeasurement(null);
                  setMName('');
                  setMPhone('');
                  setShowNewMeasurementModal(true);
                }}
                className="px-4 py-2.5 rounded bg-[#C5A059] text-stone-950 font-bold text-xs uppercase tracking-wider hover:bg-[#d6b066] transition-all flex items-center gap-2 shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Add Customer Measurement Profile</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredMeasurements.map((m) => (
                <div
                  key={m.id}
                  className="bg-stone-900 border border-stone-800 rounded-lg p-5 space-y-4 text-xs"
                >
                  <div className="flex items-center justify-between border-b border-stone-800 pb-3">
                    <div>
                      <h4 className="font-serif-title text-lg font-semibold text-white">{m.customerName}</h4>
                      <p className="text-stone-400 text-[11px] font-mono">{m.phone} • {m.email || 'No email'}</p>
                    </div>
                    <button
                      onClick={() => {
                        setEditingMeasurement(m);
                        setMName(m.customerName);
                        setMPhone(m.phone);
                        setMChest(m.chest);
                        setMWaist(m.waist);
                        setMShoulder(m.shoulder);
                        setMSleeve(m.sleeve);
                        setMNeck(m.neck);
                        setMHip(m.hip);
                        setMInseam(m.inseam);
                        setMHeight(m.heightCm || 180);
                        setMFit(m.preferredFit);
                        setMNotes(m.postureNotes || '');
                        setShowNewMeasurementModal(true);
                      }}
                      className="p-2 rounded bg-stone-800 hover:bg-stone-700 text-[#C5A059]"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Body Metrics Grid */}
                  <div className="grid grid-cols-4 gap-2 text-center text-stone-200">
                    <div className="bg-stone-950 p-2 rounded border border-stone-800">
                      <span className="text-[9px] uppercase text-stone-500 block">Chest</span>
                      <span className="font-mono font-bold text-[#C5A059] text-sm">{m.chest}"</span>
                    </div>
                    <div className="bg-stone-950 p-2 rounded border border-stone-800">
                      <span className="text-[9px] uppercase text-stone-500 block">Waist</span>
                      <span className="font-mono font-bold text-[#C5A059] text-sm">{m.waist}"</span>
                    </div>
                    <div className="bg-stone-950 p-2 rounded border border-stone-800">
                      <span className="text-[9px] uppercase text-stone-500 block">Shoulder</span>
                      <span className="font-mono font-bold text-stone-200 text-sm">{m.shoulder}"</span>
                    </div>
                    <div className="bg-stone-950 p-2 rounded border border-stone-800">
                      <span className="text-[9px] uppercase text-stone-500 block">Sleeve</span>
                      <span className="font-mono font-bold text-stone-200 text-sm">{m.sleeve}"</span>
                    </div>
                  </div>

                  <div className="text-[11px] text-stone-400 space-y-1">
                    <p>Neck: <strong>{m.neck}"</strong> | Hip: <strong>{m.hip}"</strong> | Inseam: <strong>{m.inseam}"</strong> | Height: <strong>{m.heightCm}cm</strong></p>
                    {m.postureNotes && <p className="italic text-stone-300">Posture: {m.postureNotes}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ------------------- TAB 3: INQUIRIES ------------------- */}
        {activeAdminTab === 'inquiries' && (
          <div className="space-y-6">
            <h3 className="font-serif-title text-xl text-white border-b border-stone-800 pb-3">
              Incoming Guest Fitting Inquiries
            </h3>

            <div className="space-y-4">
              {inquiries.map((inq) => (
                <div
                  key={inq.id}
                  className="bg-stone-900 border border-stone-800 rounded-lg p-5 space-y-3 text-xs"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-800 pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-stone-400">{inq.id}</span>
                        <h4 className="font-semibold text-white text-sm">{inq.customerName}</h4>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            inq.status === 'new'
                              ? 'bg-amber-500/20 text-amber-300'
                              : inq.status === 'converted'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-stone-800 text-stone-300'
                          }`}
                        >
                          {inq.status}
                        </span>
                      </div>
                      <p className="text-stone-400 mt-1">
                        Phone: <strong className="text-stone-200">{inq.phone}</strong> | Email: {inq.email}
                      </p>
                    </div>

                    {inq.status !== 'converted' && (
                      <button
                        onClick={() => handleConvertInquiry(inq)}
                        className="px-4 py-2 rounded bg-[#C5A059] text-stone-950 font-bold text-xs uppercase tracking-wider hover:bg-[#d6b066] transition-all flex items-center gap-1.5 shrink-0"
                      >
                        <Scissors className="w-3.5 h-3.5" />
                        <span>Convert to Order</span>
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-stone-300">
                    <div>
                      <span className="text-stone-500 block text-[10px] uppercase">Service Requested</span>
                      <p className="font-medium text-white">{inq.serviceRequested}</p>
                    </div>
                    <div>
                      <span className="text-stone-500 block text-[10px] uppercase">Fabric Preference</span>
                      <p className="font-medium text-white">{inq.fabricPreference || 'Atelier Pick'}</p>
                    </div>
                  </div>

                  {inq.message && (
                    <div className="bg-stone-950 p-3 rounded border border-stone-800 text-stone-300 italic">
                      "{inq.message}"
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ------------------- TAB 4: CATALOG & FABRICS ------------------- */}
        {activeAdminTab === 'catalog' && (
          <div className="space-y-10">
            {/* Services List */}
            <div className="space-y-4">
              <h3 className="font-serif-title text-xl text-white border-b border-stone-800 pb-3">
                Atelier Service Offerings
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                {services.map((srv) => (
                  <div key={srv.id} className="bg-stone-900 border border-stone-800 rounded p-4 space-y-2">
                    <div className="flex justify-between items-center">
                      <h4 className="font-serif-title text-base font-semibold text-white">{srv.title}</h4>
                      <span className="font-mono text-[#C5A059] font-bold">₦{srv.startingPrice.toLocaleString()}</span>
                    </div>
                    <p className="text-stone-400 text-[11px]">{srv.description}</p>
                    <span className="text-stone-500 font-mono text-[10px] block">Turnaround: {srv.turnaroundDays} Days</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Fabrics Reserve */}
            <div className="space-y-4">
              <h3 className="font-serif-title text-xl text-white border-b border-stone-800 pb-3">
                Heritage Fabrics Reserve
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                {fabrics.map((fab) => (
                  <div key={fab.id} className="bg-stone-900 border border-stone-800 rounded p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-6 h-6 rounded-full border border-stone-600 shrink-0" style={{ backgroundColor: fab.colorHex }} />
                      <div>
                        <h4 className="font-semibold text-white">{fab.name}</h4>
                        <p className="text-stone-400 text-[11px]">{fab.composition} ({fab.origin})</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-[#C5A059] bg-stone-950 px-2 py-1 rounded border border-stone-800">{fab.priceTier}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ------------------- TAB 5: SUBSCRIBERS ------------------- */}
        {activeAdminTab === 'subscribers' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-stone-800 pb-4">
              <h3 className="font-serif-title text-xl text-white">
                Email Announcement Subscribers ({subscribers.length})
              </h3>
              <button
                onClick={() => {
                  const csvContent = 'data:text/csv;charset=utf-8,' + ['Name,Email,Preference,SubscribedAt'].concat(subscribers.map(s => `${s.name},${s.email},${s.preference},${s.subscribedAt}`)).join('\n');
                  const encodedUri = encodeURI(csvContent);
                  const link = document.createElement('a');
                  link.setAttribute('href', encodedUri);
                  link.setAttribute('download', 'atelier_subscribers.csv');
                  document.body.appendChild(link);
                  link.click();
                }}
                className="px-3.5 py-2 rounded bg-stone-800 text-stone-200 text-xs font-semibold hover:bg-stone-700 flex items-center gap-1.5"
              >
                <Download className="w-4 h-4 text-[#C5A059]" /> Export CSV List
              </button>
            </div>

            <div className="bg-stone-900 border border-stone-800 rounded-lg overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-stone-950 text-stone-400 uppercase text-[10px] tracking-wider border-b border-stone-800">
                  <tr>
                    <th className="p-3">Client Name</th>
                    <th className="p-3">Email Address</th>
                    <th className="p-3">Preference</th>
                    <th className="p-3">Subscribed Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-800 text-stone-200">
                  {subscribers.map((sub) => (
                    <tr key={sub.id} className="hover:bg-stone-850">
                      <td className="p-3 font-semibold text-white">{sub.name}</td>
                      <td className="p-3 font-mono text-[#C5A059]">{sub.email}</td>
                      <td className="p-3 capitalize">{sub.preference.replace('_', ' ')}</td>
                      <td className="p-3 font-mono text-stone-400">{new Date(sub.subscribedAt).toLocaleDateString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ------------------- TAB 6: SETTINGS ------------------- */}
        {activeAdminTab === 'settings' && (
          <form onSubmit={handleSaveSettings} className="bg-stone-900 border border-stone-800 rounded-lg p-6 sm:p-8 space-y-6 text-xs max-w-2xl">
            <h3 className="font-serif-title text-xl text-white border-b border-stone-800 pb-3">
              Atelier Operating Details & Content Settings
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-stone-400 uppercase text-[10px] block font-semibold">Atelier Name</label>
                <input
                  type="text"
                  value={settingsForm.shopName}
                  onChange={(e) => setSettingsForm({ ...settingsForm, shopName: e.target.value })}
                  className="w-full bg-stone-950 border border-stone-800 rounded p-2.5 text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-stone-400 uppercase text-[10px] block font-semibold">Concierge Hotline</label>
                <input
                  type="text"
                  value={settingsForm.phone}
                  onChange={(e) => setSettingsForm({ ...settingsForm, phone: e.target.value })}
                  className="w-full bg-stone-950 border border-stone-800 rounded p-2.5 text-white font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-stone-400 uppercase text-[10px] block font-semibold">Flagship Address</label>
                <input
                  type="text"
                  value={settingsForm.address}
                  onChange={(e) => setSettingsForm({ ...settingsForm, address: e.target.value })}
                  className="w-full bg-stone-950 border border-stone-800 rounded p-2.5 text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-stone-400 uppercase text-[10px] block font-semibold">City & Country</label>
                <input
                  type="text"
                  value={settingsForm.cityCountry}
                  onChange={(e) => setSettingsForm({ ...settingsForm, cityCountry: e.target.value })}
                  className="w-full bg-stone-950 border border-stone-800 rounded p-2.5 text-white"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-stone-400 uppercase text-[10px] block font-semibold">Staff Admin PIN Code</label>
              <input
                type="text"
                value={settingsForm.adminPin}
                onChange={(e) => setSettingsForm({ ...settingsForm, adminPin: e.target.value })}
                className="w-full bg-stone-950 border border-stone-800 rounded p-2.5 text-white font-mono font-bold"
              />
            </div>

            {settingsSavedMsg && (
              <p className="text-xs text-emerald-400 bg-emerald-950/40 p-2 rounded border border-emerald-900 text-center">
                ✓ Atelier Settings successfully updated!
              </p>
            )}

            <button
              type="submit"
              className="py-3 px-6 rounded bg-[#C5A059] text-stone-950 font-bold uppercase tracking-wider hover:bg-[#d6b066]"
            >
              Save Atelier Configuration
            </button>
          </form>
        )}
      </div>

      {/* NEW ORDER MODAL */}
      {showNewOrderModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-xs">
          <div className="bg-stone-900 border border-stone-800 text-stone-100 rounded-lg max-w-lg w-full p-6 space-y-4 text-xs">
            <h3 className="font-serif-title text-xl text-white border-b border-stone-800 pb-2">
              Create New Bespoke Order
            </h3>
            <form onSubmit={handleCreateOrderSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-stone-400 uppercase text-[10px] block">Client Name *</label>
                  <input
                    type="text"
                    required
                    value={newOrderCustomer}
                    onChange={(e) => setNewOrderCustomer(e.target.value)}
                    className="w-full bg-stone-950 border border-stone-800 rounded p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-stone-400 uppercase text-[10px] block">Phone *</label>
                  <input
                    type="text"
                    required
                    value={newOrderPhone}
                    onChange={(e) => setNewOrderPhone(e.target.value)}
                    className="w-full bg-stone-950 border border-stone-800 rounded p-2 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-stone-400 uppercase text-[10px] block">Service</label>
                <select
                  value={newOrderService}
                  onChange={(e) => setNewOrderService(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-800 rounded p-2 text-white"
                >
                  {services.map((s) => (
                    <option key={s.id} value={s.title}>
                      {s.title}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-stone-400 uppercase text-[10px] block">Fabric Cloth</label>
                <select
                  value={newOrderFabric}
                  onChange={(e) => setNewOrderFabric(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-800 rounded p-2 text-white"
                >
                  {fabrics.map((f) => (
                    <option key={f.id} value={f.name}>
                      {f.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-stone-400 uppercase text-[10px] block">Total Price (₦)</label>
                  <input
                    type="number"
                    value={newOrderPrice}
                    onChange={(e) => setNewOrderPrice(Number(e.target.value))}
                    className="w-full bg-stone-950 border border-stone-800 rounded p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-stone-400 uppercase text-[10px] block">Deposit Amount (₦)</label>
                  <input
                    type="number"
                    value={newOrderDeposit}
                    onChange={(e) => setNewOrderDeposit(Number(e.target.value))}
                    className="w-full bg-stone-950 border border-stone-800 rounded p-2 text-white font-mono"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowNewOrderModal(false)}
                  className="px-4 py-2 bg-stone-800 rounded text-stone-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#C5A059] text-stone-950 font-bold rounded"
                >
                  Create Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* NEW/EDIT MEASUREMENT MODAL */}
      {showNewMeasurementModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-xs">
          <div className="bg-stone-900 border border-stone-800 text-stone-100 rounded-lg max-w-md w-full p-6 space-y-4 text-xs max-h-[90vh] overflow-y-auto">
            <h3 className="font-serif-title text-xl text-white border-b border-stone-800 pb-2">
              {editingMeasurement ? 'Edit Measurement Profile' : 'Add Measurement Profile'}
            </h3>
            <form onSubmit={handleMeasurementSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-stone-400 uppercase text-[10px] block">Customer Name *</label>
                  <input
                    type="text"
                    required
                    value={mName}
                    onChange={(e) => setMName(e.target.value)}
                    className="w-full bg-stone-950 border border-stone-800 rounded p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-stone-400 uppercase text-[10px] block">Phone *</label>
                  <input
                    type="text"
                    required
                    value={mPhone}
                    onChange={(e) => setMPhone(e.target.value)}
                    className="w-full bg-stone-950 border border-stone-800 rounded p-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2">
                <div>
                  <label className="text-stone-400 uppercase text-[9px] block">Chest (in)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={mChest}
                    onChange={(e) => setMChest(Number(e.target.value))}
                    className="w-full bg-stone-950 border border-stone-800 rounded p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-stone-400 uppercase text-[9px] block">Waist (in)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={mWaist}
                    onChange={(e) => setMWaist(Number(e.target.value))}
                    className="w-full bg-stone-950 border border-stone-800 rounded p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-stone-400 uppercase text-[9px] block">Shoulder</label>
                  <input
                    type="number"
                    step="0.5"
                    value={mShoulder}
                    onChange={(e) => setMShoulder(Number(e.target.value))}
                    className="w-full bg-stone-950 border border-stone-800 rounded p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-stone-400 uppercase text-[9px] block">Sleeve</label>
                  <input
                    type="number"
                    step="0.5"
                    value={mSleeve}
                    onChange={(e) => setMSleeve(Number(e.target.value))}
                    className="w-full bg-stone-950 border border-stone-800 rounded p-1.5 text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-stone-400 uppercase text-[10px] block">Posture Notes</label>
                <textarea
                  value={mNotes}
                  onChange={(e) => setMNotes(e.target.value)}
                  rows={2}
                  className="w-full bg-stone-950 border border-stone-800 rounded p-2 text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewMeasurementModal(false)}
                  className="px-4 py-2 bg-stone-800 rounded text-stone-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#C5A059] text-stone-950 font-bold rounded"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
