import React, { useState } from 'react';
import { X, ShieldCheck, Lock, Sparkles, Loader2 } from 'lucide-react';
import { apiClient } from '../../lib/api-client';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: any) => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
}) => {
  const [pinInput, setPinInput] = useState('1234');
  const [emailInput, setEmailInput] = useState('admin@atelierhaute.com');
  const [authMode, setAuthMode] = useState<'pin' | 'email'>('pin');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg(null);

    try {
      const credentials = authMode === 'pin' ? { pin: pinInput } : { email: emailInput, password: pinInput };
      const { user } = await apiClient.login(credentials);
      setPinInput('');
      onLoginSuccess(user);
    } catch (err: any) {
      setErrorMsg(err.message || 'Authentication failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-stone-900 border border-stone-800 text-stone-100 rounded-lg max-w-sm w-full p-6 sm:p-8 relative shadow-2xl space-y-6">
        {/* DEMO MODE Badge */}
        <div className="absolute top-3 left-4 inline-flex items-center gap-1 bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/40 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded">
          <Sparkles className="w-3 h-3" /> DEMO MODE AUTHENTICATION
        </div>

        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-stone-400 hover:text-white p-1 rounded-full"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center space-y-2 pt-4">
          <div className="w-12 h-12 rounded-full bg-[#C5A059]/20 text-[#C5A059] flex items-center justify-center mx-auto border border-[#C5A059]/30">
            <Lock className="w-6 h-6" />
          </div>
          <h3 className="font-serif-title text-2xl text-white">
            Atelier Staff Portal
          </h3>
          <p className="text-stone-400 text-xs font-light">
            Authenticate to manage orders, customer measurements, and shop catalog.
          </p>
        </div>

        {/* Tab Toggle */}
        <div className="flex bg-stone-950 p-1 rounded border border-stone-800 text-xs">
          <button
            type="button"
            onClick={() => setAuthMode('pin')}
            className={`flex-1 py-1.5 rounded text-center font-medium transition-all ${
              authMode === 'pin' ? 'bg-[#C5A059] text-stone-950 font-semibold' : 'text-stone-400 hover:text-white'
            }`}
          >
            Staff PIN
          </button>
          <button
            type="button"
            onClick={() => setAuthMode('email')}
            className={`flex-1 py-1.5 rounded text-center font-medium transition-all ${
              authMode === 'email' ? 'bg-[#C5A059] text-stone-950 font-semibold' : 'text-stone-400 hover:text-white'
            }`}
          >
            Email & Password
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {authMode === 'email' && (
            <div className="space-y-1.5">
              <label className="text-[11px] uppercase tracking-wider text-stone-400 font-semibold block">
                Staff Email
              </label>
              <input
                type="email"
                required
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                placeholder="admin@atelierhaute.com"
                className="w-full bg-stone-950 border border-stone-800 rounded p-3 text-sm text-white focus:outline-none focus:border-[#C5A059]"
              />
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-[11px] uppercase tracking-wider text-stone-400 font-semibold block">
              {authMode === 'pin' ? 'Admin PIN Code' : 'Password / PIN'}
            </label>
            <input
              type="password"
              required
              value={pinInput}
              onChange={(e) => setPinInput(e.target.value)}
              placeholder={authMode === 'pin' ? 'e.g. 1234' : '••••••••'}
              className="w-full bg-stone-950 border border-stone-800 rounded p-3 text-center text-lg font-mono tracking-widest text-white focus:outline-none focus:border-[#C5A059]"
              autoFocus
            />
            <p className="text-[10px] text-stone-500 text-center">
              Demo Staff PIN: <code className="text-[#C5A059] font-mono">1234</code>
            </p>
          </div>

          {errorMsg && (
            <p className="text-xs text-red-400 bg-red-950/40 p-2 rounded border border-red-900 text-center font-medium">
              {errorMsg}
            </p>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 rounded bg-[#C5A059] text-stone-950 font-bold text-xs uppercase tracking-wider hover:bg-[#d6b066] transition-all flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin text-stone-950" />
            ) : (
              <ShieldCheck className="w-4 h-4" />
            )}
            <span>{isLoading ? 'Authenticating...' : 'Authenticate Staff Session'}</span>
          </button>
        </form>

        <div className="text-[10px] text-stone-500 text-center border-t border-stone-800/80 pt-3">
          Calls <code className="text-stone-400 font-mono">apiClient.login()</code> → Swappable to NestJS REST Auth API
        </div>
      </div>
    </div>
  );
};
