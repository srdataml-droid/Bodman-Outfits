import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Phone, Mail, Clock, ShieldCheck, Scissors } from 'lucide-react';
import { ShopSettings } from '../types';

interface ContactSectionProps {
  shopSettings: ShopSettings;
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  shopSettings,
}) => {
  return (
    <section className="py-16 bg-[#1C1917] text-stone-100 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-xs uppercase tracking-widest text-[#C5A059] font-semibold">
            Visit Our Flagship Atelier
          </span>
          <h2 className="font-serif-title text-3xl sm:text-4xl font-normal text-white">
            Where Craft Meets Personal Identity
          </h2>
          <p className="text-stone-300 text-sm font-light leading-relaxed">
            Experience private canvas fitting sessions in our Victoria Island flagship suite.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Info Card */}
          <div className="lg:col-span-5 bg-stone-900 border border-stone-800 rounded-lg p-6 sm:p-8 space-y-6 flex flex-col justify-between">
            <div className="space-y-6">
              <div className="flex items-center gap-3 border-b border-stone-800 pb-4">
                <div className="w-10 h-10 rounded bg-[#C5A059]/20 text-[#C5A059] flex items-center justify-center">
                  <Scissors className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif-title text-xl text-white">{shopSettings.shopName}</h3>
                  <span className="text-[11px] text-stone-400">Master Bespoke Tailoring</span>
                </div>
              </div>

              <div className="space-y-4 text-xs text-stone-300">
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-white block text-xs">Flagship Address</span>
                    <p className="text-stone-300">{shopSettings.address}</p>
                    <p className="text-stone-300">{shopSettings.cityCountry}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-white block text-xs">Atelier Hotline</span>
                    <p className="font-mono text-stone-200">{shopSettings.phone}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-white block text-xs">Email Concierge</span>
                    <p className="text-stone-300">{shopSettings.email}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 pt-3 border-t border-stone-800">
                  <Clock className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-white block text-xs">Fitting Hours</span>
                    <p>Mon – Fri: {shopSettings.hoursWeekday}</p>
                    <p>Sat: {shopSettings.hoursSaturday}</p>
                    <p>Sun: {shopSettings.hoursSunday}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-stone-800">
              <Link
                to="/inquiry"
                className="w-full py-3 rounded bg-[#C5A059] text-stone-950 font-semibold text-xs uppercase tracking-wider hover:bg-[#d6b066] transition-all flex items-center justify-center shadow-xs"
              >
                Book Private Fitting Appointment
              </Link>
            </div>
          </div>

          {/* Map Visual Card */}
          <div className="lg:col-span-7 bg-stone-900 border border-stone-800 rounded-lg overflow-hidden relative flex flex-col justify-between min-h-[340px]">
            <div className="relative flex-1 bg-stone-950 p-6 flex flex-col items-center justify-center text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#C5A059]/15 border border-[#C5A059]/30 text-[#C5A059] flex items-center justify-center">
                <MapPin className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <h4 className="font-serif-title text-xl text-white">Victoria Island Atelier Suite</h4>
                <p className="text-xs text-stone-400 max-w-sm">
                  {shopSettings.address}, {shopSettings.cityCountry}
                </p>
              </div>

              <div className="inline-flex items-center gap-2 px-3 py-1 bg-stone-900 border border-stone-800 rounded text-[11px] text-[#C5A059] font-mono">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Valet Parking & Private Suite Available</span>
              </div>
            </div>

            <div className="p-4 bg-stone-950 border-t border-stone-800 text-[11px] text-stone-400 text-center">
              Walk-in consultations welcome during weekday operating hours.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
