import React, { useState } from 'react';
import { X, Mail, CheckCircle2, Sparkles } from 'lucide-react';

interface MailingListModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubscribe: (name: string, email: string, preference: string) => Promise<{ success: boolean; message: string }>;
}

export const MailingListModal: React.FC<MailingListModalProps> = ({
  isOpen,
  onClose,
  onSubscribe,
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [preference, setPreference] = useState('all');
  const [loading, setLoading] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setStatusMsg('Please provide a valid email address.');
      return;
    }

    setLoading(true);
    setStatusMsg(null);

    try {
      const res = await onSubscribe(name, email, preference);
      setIsSuccess(true);
      setStatusMsg(res.message || 'Thank you for subscribing to Atelier Haute fabric drops.');
    } catch (err: any) {
      setStatusMsg(err.message || 'Subscription failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-stone-900 border border-stone-800 text-stone-100 rounded-lg max-w-md w-full p-6 sm:p-8 relative shadow-2xl space-y-6">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-stone-400 hover:text-white p-1 rounded-full"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-full bg-[#C5A059]/20 text-[#C5A059] flex items-center justify-center mx-auto">
            <Mail className="w-6 h-6" />
          </div>
          <h3 className="font-serif-title text-2xl text-white">
            Bespoke Fabric Drops & Announcements
          </h3>
          <p className="text-stone-400 text-xs leading-relaxed font-light">
            Receive exclusive updates on rare wool shipments from Biella, silk velvet arrivals, and seasonal lookbook releases.
          </p>
        </div>

        {isSuccess ? (
          <div className="text-center py-6 space-y-4">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <p className="text-xs text-stone-200 font-medium">{statusMsg}</p>
            <button
              onClick={onClose}
              className="px-6 py-2 bg-[#C5A059] text-stone-950 font-semibold text-xs rounded uppercase tracking-wider hover:bg-[#d6b066]"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1">
              <label className="text-[11px] uppercase tracking-wider text-stone-400 font-semibold block">
                Your Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Adebayo Ogunlesi"
                className="w-full bg-stone-950 border border-stone-800 rounded p-2.5 text-xs text-stone-100 focus:outline-none focus:border-[#C5A059]"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] uppercase tracking-wider text-stone-400 font-semibold block">
                Email Address *
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="client@example.com"
                className="w-full bg-stone-950 border border-stone-800 rounded p-2.5 text-xs text-stone-100 focus:outline-none focus:border-[#C5A059]"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] uppercase tracking-wider text-stone-400 font-semibold block">
                Notification Preference
              </label>
              <select
                value={preference}
                onChange={(e) => setPreference(e.target.value)}
                className="w-full bg-stone-950 border border-stone-800 rounded p-2.5 text-xs text-stone-100 focus:outline-none focus:border-[#C5A059]"
              >
                <option value="all">All Announcements & Fabric Drops</option>
                <option value="fabric_arrivals">New Fabric & Textile Arrivals Only</option>
                <option value="bespoke_drops">Bespoke Collection Lookbooks</option>
                <option value="style_guides">Wedding & Formalwear Style Guides</option>
              </select>
            </div>

            {statusMsg && (
              <p className="text-xs text-red-400 bg-red-950/30 p-2 rounded border border-red-900 text-center">
                {statusMsg}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded bg-[#C5A059] text-stone-950 font-semibold text-xs uppercase tracking-wider hover:bg-[#d6b066] transition-all flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>{loading ? 'Subscribing...' : 'Subscribe to Email Updates'}</span>
            </button>

            <p className="text-[10px] text-stone-500 text-center">
              No account required. Unsubscribe anytime in one click.
            </p>
          </form>
        )}
      </div>
    </div>
  );
};
