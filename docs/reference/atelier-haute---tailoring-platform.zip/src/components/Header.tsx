import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  Scissors,
  Search,
  Sparkles,
  Ruler,
  ShoppingBag,
  Mail,
  ShieldCheck,
  MessageSquare,
  Menu,
  X,
} from 'lucide-react';
import { ShopSettings } from '../types';

interface HeaderProps {
  shopSettings: ShopSettings;
  onOpenMailingList: () => void;
  onOpenAiAssistant: () => void;
  onOpenAdminLogin: () => void;
  isAdminLoggedIn: boolean;
  onAdminLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  shopSettings,
  onOpenMailingList,
  onOpenAiAssistant,
  onOpenAdminLogin,
  isAdminLoggedIn,
  onAdminLogout,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const navItems = [
    { path: '/', label: 'Services & Catalog', icon: ShoppingBag },
    { path: '/visualizer', label: 'AI Garment Visualizer', icon: Sparkles },
    { path: '/size-fit', label: 'Fit & Size Calculator', icon: Ruler },
    { path: '/tracker', label: 'Track Order', icon: Search },
    { path: '/inquiry', label: 'Order Inquiry', icon: Scissors },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#FAF9F6]/95 backdrop-blur-md border-b border-stone-200 text-stone-900 transition-all">
      {/* Top Banner Notice with DEMO MODE Indicator */}
      <div className="bg-stone-900 text-stone-300 text-xs py-1.5 px-4 text-center tracking-wider flex items-center justify-center gap-3 flex-wrap">
        <span className="bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/40 font-bold px-2 py-0.5 rounded text-[10px] uppercase tracking-wider">
          ⚡ DEMO MODE
        </span>
        <span className="text-stone-300 text-[11px]">Mock Data API Active</span>
        <span className="hidden md:inline text-stone-600">•</span>
        <span className="hidden lg:inline text-stone-400 text-[11px]">{shopSettings.tagline}</span>
        <span className="hidden md:inline text-stone-600">•</span>
        <button
          onClick={onOpenMailingList}
          className="inline-flex items-center gap-1 text-[#C5A059] hover:underline font-medium text-[11px]"
        >
          <Mail className="w-3 h-3" /> New Fabric Drop Alerts
        </button>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Brand Logo */}
          <Link
            to="/"
            className="flex items-center gap-3 group"
          >
            <div className="w-10 h-10 rounded-sm bg-stone-900 text-[#C5A059] flex items-center justify-center shadow-xs group-hover:bg-[#C5A059] group-hover:text-stone-900 transition-colors">
              <Scissors className="w-5 h-5" />
            </div>
            <div>
              <span className="font-serif-title text-2xl font-bold tracking-tight text-stone-900 block leading-tight">
                {shopSettings.shopName.split(' ')[0]} <span className="italic font-normal text-[#C5A059]">{shopSettings.shopName.split(' ').slice(1).join(' ')}</span>
              </span>
              <span className="text-[10px] uppercase tracking-widest text-stone-500 font-medium">
                Bespoke Atelier • Lagos
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`px-3.5 py-2 rounded-md text-xs font-medium tracking-wide uppercase transition-all flex items-center gap-2 ${
                    isActive
                      ? 'bg-stone-900 text-white shadow-xs'
                      : 'text-stone-700 hover:text-stone-900 hover:bg-stone-200/60'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#C5A059]' : 'text-stone-500'}`} />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          {/* Action Buttons */}
          <div className="hidden sm:flex items-center gap-2.5">
            <button
              onClick={onOpenAiAssistant}
              className="px-3 py-2 rounded-md border border-stone-300 bg-white text-stone-800 text-xs font-medium hover:border-[#C5A059] hover:text-[#C5A059] transition-all flex items-center gap-1.5 shadow-xs"
              title="Ask AI Concierge"
            >
              <MessageSquare className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>AI Concierge</span>
            </button>

            {isAdminLoggedIn ? (
              <div className="flex items-center gap-2">
                <Link
                  to="/admin"
                  className={`px-3 py-2 rounded-md text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 transition-all ${
                    location.pathname === '/admin'
                      ? 'bg-[#C5A059] text-stone-900 shadow-xs'
                      : 'bg-stone-900 text-stone-100 hover:bg-stone-800'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Admin Portal</span>
                </Link>
                <button
                  onClick={() => {
                    onAdminLogout();
                    navigate('/');
                  }}
                  className="text-xs text-stone-500 hover:text-red-600 px-2 py-1 font-medium"
                >
                  Exit
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenAdminLogin}
                className="px-3 py-2 rounded-md text-xs font-medium text-stone-600 hover:text-stone-900 hover:bg-stone-200/50 flex items-center gap-1.5"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-stone-400" />
                <span>Atelier Staff</span>
              </button>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <div className="lg:hidden flex items-center gap-2">
            <button
              onClick={onOpenAiAssistant}
              className="p-2 rounded-md bg-stone-100 text-[#C5A059]"
            >
              <MessageSquare className="w-5 h-5" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-md text-stone-700 hover:bg-stone-200"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-stone-200 bg-[#FAF9F6] px-4 pt-3 pb-6 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setMobileMenuOpen(false)}
                className={`w-full px-4 py-2.5 rounded-md text-sm font-medium tracking-wide flex items-center gap-3 text-left ${
                  isActive ? 'bg-stone-900 text-white' : 'text-stone-800 hover:bg-stone-200'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-[#C5A059]' : 'text-stone-500'}`} />
                {item.label}
              </Link>
            );
          })}

          <div className="pt-3 border-t border-stone-200 flex flex-col gap-2">
            <button
              onClick={() => {
                onOpenMailingList();
                setMobileMenuOpen(false);
              }}
              className="w-full px-4 py-2 rounded-md border border-stone-300 text-xs font-medium text-stone-800 flex items-center gap-2 justify-center"
            >
              <Mail className="w-4 h-4 text-[#C5A059]" /> Subscribe to Fabric Drops
            </button>

            {isAdminLoggedIn ? (
              <Link
                to="/admin"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full px-4 py-2 rounded-md bg-[#C5A059] text-stone-900 text-xs font-bold uppercase tracking-wider flex items-center gap-2 justify-center"
              >
                <ShieldCheck className="w-4 h-4" /> Admin Portal Active
              </Link>
            ) : (
              <button
                onClick={() => {
                  onOpenAdminLogin();
                  setMobileMenuOpen(false);
                }}
                className="w-full px-4 py-2 rounded-md bg-stone-900 text-white text-xs font-medium flex items-center gap-2 justify-center"
              >
                <ShieldCheck className="w-4 h-4 text-[#C5A059]" /> Staff Portal Access
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
