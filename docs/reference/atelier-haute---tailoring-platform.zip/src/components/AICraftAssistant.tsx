import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Send,
  Sparkles,
  Bot,
  User,
  Scissors,
  Cpu,
} from 'lucide-react';
import { AIChatMessage, ShopSettings } from '../types';
import { apiClient } from '../lib/api-client';

interface AICraftAssistantProps {
  isOpen: boolean;
  onClose: () => void;
  shopSettings: ShopSettings;
}

export const AICraftAssistant: React.FC<AICraftAssistantProps> = ({
  isOpen,
  onClose,
  shopSettings,
}) => {
  const [messages, setMessages] = useState<AIChatMessage[]>([
    {
      id: 'msg-1',
      sender: 'assistant',
      text: `Welcome to ${shopSettings.shopName}. I am your AI Craft Concierge. How may I assist you with our bespoke tailoring services, fabric selections, fitting appointments, or pricing today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [aiSource, setAiSource] = useState<'Ollama Cloud AI' | 'Rule-based Demo Concierge'>('Rule-based Demo Concierge');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const quickPrompts = [
    'What are your bespoke suit prices?',
    'How long does a wedding tuxedo take?',
    'Where is the Lagos atelier located?',
    'How does the canvas fitting process work?',
  ];

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, loading]);

  if (!isOpen) return null;

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query) return;

    const userMsg: AIChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setLoading(true);

    try {
      const res = await apiClient.askAIConcierge(query, messages);
      setAiSource(res.source);

      const botMsg: AIChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'assistant',
        text: res.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: `msg-err-${Date.now()}`,
          sender: 'assistant',
          text: `Atelier Haute specializes in bespoke menswear. You can reach our concierge directly at ${shopSettings.phone}.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-stone-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-stone-900 border-l border-stone-800 text-stone-100 w-full max-w-lg h-full flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-800 flex items-center justify-between bg-stone-950">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded bg-[#C5A059] text-stone-950 flex items-center justify-center font-bold shadow-sm">
              <Scissors className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-serif-title text-lg font-normal text-white">
                  Atelier AI Concierge
                </h3>
                <span className="px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/30 flex items-center gap-1">
                  <Cpu className="w-3 h-3" /> {aiSource}
                </span>
              </div>
              <span className="text-[10px] uppercase tracking-wider text-stone-400 font-medium block">
                Knowledge Base Grounded Assistant
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-stone-400 hover:text-white rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Question Chips */}
        <div className="p-3 bg-stone-900 border-b border-stone-800 flex items-center gap-2 overflow-x-auto text-[11px] no-scrollbar">
          <span className="text-stone-500 shrink-0 font-medium pl-1">Ask:</span>
          {quickPrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(prompt)}
              className="px-2.5 py-1 rounded-full bg-stone-800 hover:bg-[#C5A059] hover:text-stone-950 text-stone-300 transition-colors shrink-0 border border-stone-700"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Message Stream */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${
                msg.sender === 'user' ? 'flex-row-reverse' : ''
              }`}
            >
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs shrink-0 ${
                  msg.sender === 'user'
                    ? 'bg-stone-700 text-stone-200'
                    : 'bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/30'
                }`}
              >
                {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-[82%] p-3.5 rounded-lg text-xs leading-relaxed space-y-1 ${
                  msg.sender === 'user'
                    ? 'bg-[#C5A059] text-stone-950 font-medium rounded-tr-none'
                    : 'bg-stone-800 text-stone-200 border border-stone-700 rounded-tl-none'
                }`}
              >
                <p className="whitespace-pre-wrap">{msg.text}</p>
                <span className={`text-[9px] block text-right opacity-70 ${msg.sender === 'user' ? 'text-stone-900' : 'text-stone-400'}`}>
                  {msg.timestamp}
                </span>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-xs text-[#C5A059] p-2 bg-stone-800/50 rounded border border-stone-800 w-fit">
              <Sparkles className="w-4 h-4 animate-spin" />
              <span>Consulting Atelier Concierge...</span>
            </div>
          )}

          <div ref={chatEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-4 border-t border-stone-800 bg-stone-950">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about fabrics, prices, fitting sessions..."
              className="flex-1 bg-stone-900 border border-stone-800 rounded px-3.5 py-2.5 text-xs text-white placeholder-stone-500 focus:outline-none focus:border-[#C5A059]"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="p-2.5 bg-[#C5A059] text-stone-950 rounded hover:bg-[#d6b066] disabled:opacity-50 transition-colors shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
