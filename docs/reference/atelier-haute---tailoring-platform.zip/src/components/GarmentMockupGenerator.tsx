import React, { useState } from 'react';
import {
  Sparkles,
  Scissors,
  RefreshCw,
  CheckCircle2,
  Info,
} from 'lucide-react';
import { FabricOption } from '../types';
import { apiClient } from '../lib/api-client';

interface GarmentMockupGeneratorProps {
  fabrics: FabricOption[];
  onSelectMockupForInquiry: (garmentTitle: string, fabricName: string, notes: string) => void;
}

export const GarmentMockupGenerator: React.FC<GarmentMockupGeneratorProps> = ({
  fabrics,
  onSelectMockupForInquiry,
}) => {
  const [garmentType, setGarmentType] = useState('Two-Piece Suit');
  const [selectedFabric, setSelectedFabric] = useState<FabricOption>(fabrics[0] || {
    id: 'fab-1',
    name: 'Super 130s Navy Herringbone',
    origin: 'Biella, Italy',
    composition: '100% Wool',
    colorHex: '#1B2A4A',
    pattern: 'herringbone',
    priceTier: 'Premium',
    inStock: true,
    imageUrl: '',
  });
  const [cutStyle, setCutStyle] = useState('Single Breasted 2-Button');
  const [lapelType, setLapelType] = useState('Peak Lapel');
  const [additionalDetails, setAdditionalDetails] = useState('Hand-picked stitching, double vent back, cream cupro silk lining.');

  const [loading, setLoading] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(
    'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=1000&q=80'
  );
  const [mockupInfo, setMockupInfo] = useState<string | null>(
    'Bespoke Two-Piece Suit in Super 130s Navy Herringbone with Peak Lapel and Single Breasted 2-Button cut.'
  );
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const garmentTypes = [
    'Two-Piece Suit',
    'Three-Piece Executive Suit',
    'Black-Tie Wedding Tuxedo',
    'Heritage Agbada & Kaftan',
    'Double-Breasted Blazer',
  ];

  const cutStyles = [
    'Single Breasted 2-Button',
    'Double Breasted 6-Button',
    'Italian Soft Shoulder Drop 8',
    'Traditional Mandarin Collar',
  ];

  const lapelTypes = [
    'Peak Lapel',
    'Notch Lapel',
    'Shawl Collar in Silk Satin',
    'Standing Collar (Mandarin)',
  ];

  const handleGenerate = async () => {
    setLoading(true);
    setErrorMsg(null);

    try {
      const data = await apiClient.generateMockup({
        garmentType,
        fabricName: selectedFabric.name,
        fabricColor: selectedFabric.colorHex,
        cutStyle,
        lapelType,
        additionalDetails,
      });

      setGeneratedImage(data.imageUrl);
      setMockupInfo(data.description || `Custom ${garmentType} in ${selectedFabric.name}`);
    } catch (err: any) {
      console.error('Mockup error:', err);
      setErrorMsg(err.message || 'Unable to generate mockup.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-16 bg-[#1C1917] text-stone-100 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C5A059]/20 text-[#C5A059] text-xs font-semibold uppercase tracking-widest border border-[#C5A059]/30">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Garment Visualizer (Demo)</span>
          </div>
          <h2 className="font-serif-title text-3xl sm:text-4xl font-normal text-white">
            Visualize Your Bespoke Commission
          </h2>
          <p className="text-stone-300 text-sm sm:text-base font-light leading-relaxed">
            Combine European textiles, lapel cuts, and structural finishes to generate a photorealistic visual preview of your intended garment.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Controls Column */}
          <div className="lg:col-span-6 bg-stone-900 border border-stone-800 rounded-lg p-6 sm:p-8 space-y-6 shadow-xl">
            <h3 className="font-serif-title text-xl text-white border-b border-stone-800 pb-3 flex items-center gap-2">
              <Scissors className="w-5 h-5 text-[#C5A059]" />
              <span>Garment Specifications</span>
            </h3>

            {/* 1. Garment Category */}
            <div className="space-y-2">
              <label className="text-xs uppercase tracking-wider text-stone-400 font-semibold block">
                1. Garment Style
              </label>
              <div className="grid grid-cols-2 gap-2">
                {garmentTypes.map((type) => (
                  <button
                    key={type}
                    onClick={() => setGarmentType(type)}
                    className={`p-2.5 rounded text-xs font-medium text-left transition-all border ${
                      garmentType === type
                        ? 'border-[#C5A059] bg-[#C5A059]/15 text-white'
                        : 'border-stone-800 bg-stone-950/60 text-stone-300 hover:border-stone-700'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Fabric Selection */}
            <div className="space-y-2">
              <label className="text-xs uppercase tracking-wider text-stone-400 font-semibold block">
                2. Select Fabric
              </label>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {fabrics.map((fab) => (
                  <button
                    key={fab.id}
                    onClick={() => setSelectedFabric(fab)}
                    className={`w-full p-2.5 rounded text-left transition-all flex items-center justify-between border ${
                      selectedFabric.id === fab.id
                        ? 'border-[#C5A059] bg-[#C5A059]/15 text-white'
                        : 'border-stone-800 bg-stone-950/60 text-stone-300 hover:border-stone-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 text-xs">
                      <div
                        className="w-4 h-4 rounded-full border border-stone-700 shrink-0"
                        style={{ backgroundColor: fab.colorHex }}
                      />
                      <span className="font-medium text-stone-200">{fab.name}</span>
                    </div>
                    <span className="text-[10px] text-[#C5A059] font-mono">{fab.origin}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* 3. Cut & Lapel */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-wider text-stone-400 font-semibold block">
                  3. Cut Architecture
                </label>
                <select
                  value={cutStyle}
                  onChange={(e) => setCutStyle(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-800 rounded p-2.5 text-xs text-stone-200 focus:outline-none focus:border-[#C5A059]"
                >
                  {cutStyles.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs uppercase tracking-wider text-stone-400 font-semibold block">
                  4. Lapel Construction
                </label>
                <select
                  value={lapelType}
                  onChange={(e) => setLapelType(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-800 rounded p-2.5 text-xs text-stone-200 focus:outline-none focus:border-[#C5A059]"
                >
                  {lapelTypes.map((l) => (
                    <option key={l} value={l}>
                      {l}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* 5. Custom Notes */}
            <div className="space-y-2">
              <label className="text-xs uppercase tracking-wider text-stone-400 font-semibold block">
                5. Custom Detail Notes
              </label>
              <textarea
                value={additionalDetails}
                onChange={(e) => setAdditionalDetails(e.target.value)}
                rows={2}
                placeholder="e.g. Monogram 'A.O.' on inside breast pocket, ticket pocket, gold horn buttons"
                className="w-full bg-stone-950 border border-stone-800 rounded p-2.5 text-xs text-stone-200 focus:outline-none focus:border-[#C5A059]"
              />
            </div>

            {/* Submit Button */}
            <button
              onClick={handleGenerate}
              disabled={loading}
              className="w-full py-3.5 rounded bg-[#C5A059] text-stone-950 font-semibold text-xs uppercase tracking-wider hover:bg-[#d6b066] disabled:opacity-50 transition-all flex items-center justify-center gap-2 shadow-lg"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Generating Demo Preview...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Bespoke Visual Preview</span>
                </>
              )}
            </button>

            {errorMsg && (
              <p className="text-xs text-amber-400 bg-amber-950/40 border border-amber-800 p-2.5 rounded">
                {errorMsg}
              </p>
            )}
          </div>

          {/* Preview Display Column */}
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-stone-900 border border-stone-800 rounded-lg overflow-hidden shadow-2xl relative group">
              <div className="aspect-[3/4] relative bg-stone-950 flex items-center justify-center overflow-hidden">
                {loading ? (
                  <div className="text-center p-8 space-y-4">
                    <div className="w-12 h-12 rounded-full border-2 border-[#C5A059] border-t-transparent animate-spin mx-auto" />
                    <p className="text-stone-300 text-xs font-mono uppercase tracking-wider">
                      Rendering {garmentType} in {selectedFabric.name}...
                    </p>
                    <p className="text-stone-500 text-[11px]">
                      Applying floating canvas, lapel proportions & texture lighting
                    </p>
                  </div>
                ) : generatedImage ? (
                  <img
                    src={generatedImage}
                    alt="AI Generated Garment Mockup"
                    className="w-full h-full object-cover object-center transition-all duration-700"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="text-center p-8 text-stone-500 text-xs">
                    Select specifications on the left to render preview
                  </div>
                )}

                {/* Overlay Badge */}
                <div className="absolute top-4 left-4 bg-stone-950/80 backdrop-blur-md px-3 py-1.5 rounded border border-stone-800 text-[11px] text-[#C5A059] font-medium flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>DEMO PREVIEW IMAGE — Simulated Garment Rendering</span>
                </div>
              </div>

              {/* Mockup Specs Summary Footer */}
              <div className="p-6 bg-stone-900 border-t border-stone-800 space-y-4">
                <div>
                  <h4 className="font-serif-title text-xl text-white">
                    {garmentType} — {selectedFabric.name}
                  </h4>
                  <p className="text-stone-400 text-xs mt-1 leading-relaxed">
                    {mockupInfo}
                  </p>
                </div>

                <div className="pt-2 flex flex-wrap items-center gap-3">
                  <button
                    onClick={() =>
                      onSelectMockupForInquiry(
                        garmentType,
                        selectedFabric.name,
                        `Cut: ${cutStyle}, Lapel: ${lapelType}. Notes: ${additionalDetails}`
                      )
                    }
                    className="flex-1 py-3 px-4 rounded bg-[#C5A059] text-stone-950 font-semibold text-xs uppercase tracking-wider hover:bg-[#d6b066] transition-all flex items-center justify-center gap-2"
                  >
                    <Scissors className="w-4 h-4" />
                    <span>Inquire Commission For This Design</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Note on Craftsmanship */}
            <div className="bg-stone-950 border border-stone-800 rounded p-4 text-xs text-stone-400 flex items-start gap-3">
              <Info className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
              <p>
                <span className="font-semibold text-stone-200">Production Guarantee:</span> Your master tailor will review this visual reference during your baseline fitting session to align cloth drape, pocket positioning, and collar roll.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
