import React, { useState } from 'react';
import {
  Scissors,
  Send,
  CheckCircle2,
  Phone,
  Mail,
  MapPin,
  Clock,
  CreditCard,
  ShieldCheck,
  AlertTriangle,
  ExternalLink,
} from 'lucide-react';
import { FabricOption, ServiceItem, ShopSettings } from '../types';
import { apiClient } from '../lib/api-client';

interface InquiryFormProps {
  initialService?: string;
  initialFabric?: string;
  initialFitNotes?: string;
  services: ServiceItem[];
  fabrics: FabricOption[];
  shopSettings: ShopSettings;
  onSubmitInquiry: (data: any) => Promise<boolean>;
}

export const InquiryForm: React.FC<InquiryFormProps> = ({
  initialService = 'Two-Piece Bespoke Suit',
  initialFabric = '',
  initialFitNotes = '',
  services,
  fabrics,
  shopSettings,
  onSubmitInquiry,
}) => {
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [serviceRequested, setServiceRequested] = useState(initialService);
  const [fabricPreference, setFabricPreference] = useState(initialFabric);
  const [preferredFittingDate, setPreferredFittingDate] = useState('');
  const [message, setMessage] = useState(initialFitNotes);

  const [checkoutMode, setCheckoutMode] = useState<'paystack' | 'inquiry'>('paystack');
  const [loading, setLoading] = useState(false);
  const [submittedInquiryId, setSubmittedInquiryId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Selected service calculation
  const currentServiceObj = services.find((s) => s.title === serviceRequested) || services[0];
  const totalPrice = currentServiceObj?.startingPrice || 380000;
  const depositAmount = Math.round(totalPrice * (shopSettings.depositPercentage / 100));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!customerName || !phone || !email) {
      setErrorMessage('Please provide your name, phone number, and email address.');
      return;
    }

    setLoading(true);

    if (checkoutMode === 'paystack') {
      try {
        const res = await apiClient.createGuestOrder({
          customerName,
          phone,
          email,
          serviceTitle: serviceRequested,
          fabricName: fabricPreference || 'Atelier Selected Fabric',
          totalPrice,
          depositAmount,
          notes: message,
          fittingDate: preferredFittingDate,
        });

        if (res.paymentUrl) {
          // Redirect customer to Paystack authorization page
          window.location.href = res.paymentUrl;
        } else {
          setErrorMessage('Paystack payment URL was not returned. Please check server configuration.');
        }
      } catch (err: any) {
        console.error('Guest checkout error:', err);
        setErrorMessage(
          err.message || 'Unable to initialize Paystack checkout. Please verify your environment variable PAYSTACK_SECRET_KEY.'
        );
      } finally {
        setLoading(false);
      }
    } else {
      try {
        const ok = await onSubmitInquiry({
          customerName,
          phone,
          email,
          serviceRequested,
          fabricPreference,
          preferredFittingDate,
          message,
        });

        if (ok) {
          setSubmittedInquiryId(`inq-${Date.now().toString().slice(-6)}`);
        }
      } catch (err: any) {
        setErrorMessage('Failed to submit inquiry. Please try again.');
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <section className="py-16 bg-[#FAF9F6] text-stone-900">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C5A059]/15 text-[#C5A059] text-xs font-semibold uppercase tracking-widest border border-[#C5A059]/30">
            <CreditCard className="w-3.5 h-3.5" />
            <span>Paystack Guest Checkout Flow</span>
          </div>
          <h2 className="font-serif-title text-3xl sm:text-4xl font-normal text-stone-900">
            Guest Commission & Fitting Checkout
          </h2>
          <p className="text-stone-600 text-sm sm:text-base font-light leading-relaxed">
            Order your bespoke garment with optional instant deposit checkout via Paystack test mode or request an initial fitting consultation.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Form Box */}
          <div className="lg:col-span-7 bg-white border border-stone-200 rounded-lg p-6 sm:p-8 space-y-6 shadow-xs">
            {submittedInquiryId ? (
              <div className="text-center py-10 space-y-4">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="font-serif-title text-2xl text-stone-900">
                  Inquiry Received with Thanks
                </h3>
                <p className="text-xs text-stone-600 max-w-md mx-auto">
                  Reference ID: <span className="font-mono font-bold text-stone-900">{submittedInquiryId}</span>. Our concierge team will review your specifications and contact you via phone or email within 4 hours.
                </p>
                <div className="pt-4">
                  <button
                    onClick={() => {
                      setSubmittedInquiryId(null);
                      setMessage('');
                    }}
                    className="px-6 py-2.5 rounded bg-stone-900 text-white font-semibold text-xs uppercase tracking-wider hover:bg-[#C5A059] hover:text-stone-950 transition-all"
                  >
                    Submit Another Request
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Checkout Flow Mode Switcher */}
                <div className="p-1.5 bg-stone-100 rounded-lg grid grid-cols-2 gap-1 border border-stone-200 text-xs font-medium">
                  <button
                    type="button"
                    onClick={() => setCheckoutMode('paystack')}
                    className={`py-2.5 px-3 rounded-md transition-all flex items-center justify-center gap-1.5 ${
                      checkoutMode === 'paystack'
                        ? 'bg-stone-900 text-white shadow-xs'
                        : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    <CreditCard className="w-3.5 h-3.5 text-[#C5A059]" />
                    <span>Paystack Test Checkout</span>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase bg-[#C5A059]/20 text-[#C5A059]">
                      ⚡ TEST
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCheckoutMode('inquiry')}
                    className={`py-2.5 px-3 rounded-md transition-all flex items-center justify-center gap-1.5 ${
                      checkoutMode === 'inquiry'
                        ? 'bg-stone-900 text-white shadow-xs'
                        : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    <Scissors className="w-3.5 h-3.5" />
                    <span>Inquiry Only (No Deposit)</span>
                  </button>
                </div>

                {/* Test Mode Highlight Banner */}
                {checkoutMode === 'paystack' && (
                  <div className="bg-[#FAF7F0] border border-[#C5A059]/40 p-4 rounded-md space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 font-semibold text-stone-900">
                        <ShieldCheck className="w-4 h-4 text-[#C5A059]" />
                        <span>Paystack Direct Deposit (Test Mode)</span>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-[#C5A059] text-stone-950">
                        ⚡ TEST MODE
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-2 border-t border-[#C5A059]/20 text-[11px]">
                      <div>
                        <span className="text-stone-500 block">Garment Total:</span>
                        <span className="font-semibold text-stone-900">₦{totalPrice.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-stone-500 block">Deposit Required ({shopSettings.depositPercentage}%):</span>
                        <span className="font-semibold text-[#C5A059] font-mono text-sm">₦{depositAmount.toLocaleString()}</span>
                      </div>
                    </div>

                    <p className="text-[11px] text-stone-600 pt-1 leading-relaxed">
                      You will be redirected to Paystack's test checkout page. On return, payment is verified server-side before confirming your order.
                    </p>
                  </div>
                )}

                <h3 className="font-serif-title text-xl text-stone-900 border-b border-stone-100 pb-3 flex items-center gap-2">
                  <Scissors className="w-5 h-5 text-[#C5A059]" />
                  <span>Client & Commission Details</span>
                </h3>

                {/* Error Banner */}
                {errorMessage && (
                  <div className="bg-amber-50 border border-amber-300 text-amber-900 p-3.5 rounded-md text-xs flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <span className="font-semibold block">Checkout Notice</span>
                      <p>{errorMessage}</p>
                    </div>
                  </div>
                )}

                {/* Name & Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs uppercase tracking-wider text-stone-600 font-semibold block">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="e.g. Adebayo Ogunlesi"
                      className="w-full bg-stone-50 border border-stone-300 rounded p-2.5 text-xs text-stone-900 focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs uppercase tracking-wider text-stone-600 font-semibold block">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="e.g. +234 803 123 4567"
                      className="w-full bg-stone-50 border border-stone-300 rounded p-2.5 text-xs text-stone-900 focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>
                </div>

                {/* Email & Date */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs uppercase tracking-wider text-stone-600 font-semibold block">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. client@example.com"
                      className="w-full bg-stone-50 border border-stone-300 rounded p-2.5 text-xs text-stone-900 focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs uppercase tracking-wider text-stone-600 font-semibold block">
                      Preferred Fitting Date
                    </label>
                    <input
                      type="date"
                      value={preferredFittingDate}
                      onChange={(e) => setPreferredFittingDate(e.target.value)}
                      className="w-full bg-stone-50 border border-stone-300 rounded p-2.5 text-xs text-stone-900 focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>
                </div>

                {/* Service & Fabric Selection */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs uppercase tracking-wider text-stone-600 font-semibold block">
                      Service Requested
                    </label>
                    <select
                      value={serviceRequested}
                      onChange={(e) => setServiceRequested(e.target.value)}
                      className="w-full bg-stone-50 border border-stone-300 rounded p-2.5 text-xs text-stone-900 focus:outline-none focus:border-[#C5A059]"
                    >
                      {services.map((s) => (
                        <option key={s.id} value={s.title}>
                          {s.title} (From ₦{s.startingPrice.toLocaleString()})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs uppercase tracking-wider text-stone-600 font-semibold block">
                      Fabric Preference (Optional)
                    </label>
                    <select
                      value={fabricPreference}
                      onChange={(e) => setFabricPreference(e.target.value)}
                      className="w-full bg-stone-50 border border-stone-300 rounded p-2.5 text-xs text-stone-900 focus:outline-none focus:border-[#C5A059]"
                    >
                      <option value="">Atelier Recommendation</option>
                      {fabrics.map((f) => (
                        <option key={f.id} value={f.name}>
                          {f.name} ({f.origin})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Message & Fit Notes */}
                <div className="space-y-1.5">
                  <label className="text-xs uppercase tracking-wider text-stone-600 font-semibold block">
                    Custom Specifications / Event Notes / Measurements
                  </label>
                  <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    rows={3}
                    placeholder="Provide event date, design requests, or posture notes..."
                    className="w-full bg-stone-50 border border-stone-300 rounded p-2.5 text-xs text-stone-900 focus:outline-none focus:border-[#C5A059]"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3.5 rounded bg-stone-900 text-white font-semibold text-xs uppercase tracking-wider hover:bg-[#C5A059] hover:text-stone-950 transition-all flex items-center justify-center gap-2 shadow-sm"
                >
                  {checkoutMode === 'paystack' ? (
                    <>
                      <ExternalLink className="w-4 h-4 text-[#C5A059]" />
                      <span>
                        {loading
                          ? 'Initializing Paystack Checkout...'
                          : `Pay ₦${depositAmount.toLocaleString()} Deposit via Paystack (Test Mode)`}
                      </span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>{loading ? 'Submitting Inquiry...' : 'Submit Fitting & Order Inquiry'}</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </div>

          {/* Contact Details Column */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-stone-900 text-stone-100 rounded-lg p-6 sm:p-8 space-y-6 border border-stone-800 shadow-xl">
              <h3 className="font-serif-title text-2xl text-white border-b border-stone-800 pb-3">
                {shopSettings.shopName}
              </h3>

              <div className="space-y-4 text-xs text-stone-300">
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-white block">Atelier Location</span>
                    <p>{shopSettings.address}</p>
                    <p>{shopSettings.cityCountry}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-white block">Direct Concierge Hotline</span>
                    <p className="font-mono text-stone-200">{shopSettings.phone}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-white block">Email Correspondence</span>
                    <p>{shopSettings.email}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 pt-2 border-t border-stone-800">
                  <Clock className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-white block">Atelier Operating Hours</span>
                    <p>Mon – Fri: {shopSettings.hoursWeekday}</p>
                    <p>Saturday: {shopSettings.hoursSaturday}</p>
                    <p>Sunday: {shopSettings.hoursSunday}</p>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-stone-800 text-[11px] text-stone-400">
                <p className="italic">
                  "Measurements saved once, reused forever." We maintain strict privacy over client anatomical profiles.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
