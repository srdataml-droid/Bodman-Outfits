import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Scissors,
  Sparkles,
  CheckCircle2,
  Clock,
  Ruler,
  ShieldCheck,
  Search,
} from 'lucide-react';
import { ShopSettings } from '../types';

interface HeroProps {
  shopSettings: ShopSettings;
  onOpenMailingList: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  shopSettings,
  onOpenMailingList,
}) => {
  const navigate = useNavigate();

  return (
    <section className="relative bg-[#1C1917] text-stone-100 overflow-hidden py-16 lg:py-24 border-b border-stone-800">
      {/* Background Decorative Pattern */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#C5A059_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Hero Column */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#C5A059]/15 border border-[#C5A059]/30 text-[#C5A059] text-xs font-semibold uppercase tracking-widest">
              <Scissors className="w-3.5 h-3.5" />
              <span>Bespoke Tailoring & Fine Garments</span>
            </div>

            <h1 className="font-serif-title text-4xl sm:text-5xl lg:text-6xl font-normal leading-tight tracking-tight text-white">
              Anatomy of Perfection. <br />
              <span className="italic font-light text-[#C5A059]">Tailored to Your Identity.</span>
            </h1>

            <p className="text-stone-300 text-base sm:text-lg max-w-2xl font-light leading-relaxed">
              Experience master craftsmanship where precision body measurements are saved once and honored forever. From floating full-canvas two-piece suits to majestic traditional attire and wedding tuxedos.
            </p>

            {/* CTA Group */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <Link
                to="/visualizer"
                className="px-6 py-3.5 rounded-md bg-[#C5A059] text-stone-950 font-semibold text-sm tracking-wide uppercase hover:bg-[#d6b066] transition-all flex items-center gap-2 shadow-lg hover:shadow-xl"
              >
                <Sparkles className="w-4 h-4 text-stone-950" />
                <span>AI Garment Visualizer</span>
              </Link>

              <Link
                to="/tracker"
                className="px-6 py-3.5 rounded-md border border-stone-700 bg-stone-900/80 text-stone-200 hover:border-stone-500 hover:text-white font-medium text-sm tracking-wide transition-all flex items-center gap-2"
              >
                <Search className="w-4 h-4 text-[#C5A059]" />
                <span>Track Live Order</span>
              </Link>

              <Link
                to="/size-fit"
                className="px-5 py-3.5 text-stone-300 hover:text-[#C5A059] text-sm font-medium transition-colors flex items-center gap-1.5"
              >
                <Ruler className="w-4 h-4" />
                <span>Body Fit Calculator</span>
              </Link>
            </div>

            {/* Core Trust Pillars */}
            <div className="pt-8 border-t border-stone-800/80 grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs text-stone-400">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-stone-200 block text-xs">Saved Measurements</span>
                  <span>Recorded once, reused for all future commissions.</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-stone-200 block text-xs">6-Stage Live Status</span>
                  <span>Transparent timeline tracking from fabric cut to final press.</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-stone-200 block text-xs">All-Inclusive Fittings</span>
                  <span>Baseline canvas trial + 2 adjustments included up front.</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Visual Card */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md rounded-lg overflow-hidden border border-stone-800 bg-stone-900 shadow-2xl group">
              <img
                src="https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=1000&q=80"
                alt="Master Tailor Handcrafting Bespoke Suit"
                className="w-full h-[420px] object-cover object-center group-hover:scale-105 transition-transform duration-700 opacity-90"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/40 to-transparent" />

              <div className="absolute bottom-0 inset-x-0 p-6 space-y-2">
                <div className="flex items-center justify-between text-xs text-[#C5A059] font-medium tracking-widest uppercase">
                  <span>Atelier Showcase</span>
                  <span>100% Full Canvas</span>
                </div>
                <h3 className="font-serif-title text-2xl font-normal text-white">
                  Super 130s Navy Herringbone Two-Piece
                </h3>
                <p className="text-stone-300 text-xs font-light line-clamp-2">
                  Hand-stitched peak lapels, Horn buttons, and soft floating canvas tailored in our Victoria Island atelier.
                </p>
                <div className="pt-2 flex items-center justify-between text-xs border-t border-stone-800">
                  <span className="text-stone-400">Turnaround: 14 Days</span>
                  <Link
                    to="/inquiry"
                    className="text-[#C5A059] font-semibold hover:underline"
                  >
                    Inquire for Commission →
                  </Link>
                </div>
              </div>
            </div>

            {/* Floating Badge */}
            <div className="hidden sm:flex absolute -bottom-5 -left-5 bg-stone-900 border border-stone-700 p-4 rounded-md shadow-xl items-center gap-3 max-w-xs">
              <div className="w-10 h-10 rounded-full bg-[#C5A059]/20 text-[#C5A059] flex items-center justify-center shrink-0">
                <Scissors className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <p className="font-semibold text-white">No Customer Accounts Required</p>
                <p className="text-stone-400">Track orders instantly using your Reference Number.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
