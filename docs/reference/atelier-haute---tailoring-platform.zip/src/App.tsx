import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate, Navigate } from 'react-router-dom';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ServicesShowcase } from './components/ServicesShowcase';
import { GarmentMockupGenerator } from './components/GarmentMockupGenerator';
import { SizeFitAdvisor } from './components/SizeFitAdvisor';
import { OrderTracker } from './components/OrderTracker';
import { InquiryForm } from './components/InquiryForm';
import { MailingListModal } from './components/MailingListModal';
import { AICraftAssistant } from './components/AICraftAssistant';
import { ContactSection } from './components/ContactSection';
import { AdminLoginModal } from './components/admin/AdminLoginModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { ScrollToTop } from './components/ScrollToTop';

import {
  FabricOption,
  GuestInquiry,
  MeasurementProfile,
  Order,
  OrderStatus,
  PaymentStatus,
  ServiceItem,
  ShopSettings,
  Subscriber,
} from './types';

import { apiClient } from './lib/api-client';

function AppContent() {
  const navigate = useNavigate();

  // App Data States
  const [shopSettings, setShopSettings] = useState<ShopSettings>({
    shopName: 'Atelier Haute Bespoke',
    tagline: 'Master Craftsmen of Fine Tailoring & Heritage Garments',
    phone: '+234 803 123 4567',
    email: 'concierge@atelierhaute.com',
    address: '14 Victoria Island Boulevard, Phase 1',
    cityCountry: 'Lagos, Nigeria',
    hoursWeekday: '09:00 AM – 06:30 PM',
    hoursSaturday: '10:00 AM – 04:00 PM',
    hoursSunday: 'By Appointment Only',
    pricingNote: 'Prices include initial consultation, canvas baseline fitting, and 2 precision fitting adjustments.',
    depositPercentage: 50,
    adminPin: '1234',
  });
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [fabrics, setFabrics] = useState<FabricOption[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [measurements, setMeasurements] = useState<MeasurementProfile[]>([]);
  const [inquiries, setInquiries] = useState<GuestInquiry[]>([]);
  const [subscribers, setSubscribers] = useState<Subscriber[]>([]);

  // Modals
  const [mailingListOpen, setMailingListOpen] = useState(false);
  const [aiAssistantOpen, setAiAssistantOpen] = useState(false);
  const [adminLoginOpen, setAdminLoginOpen] = useState(false);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);

  // Pre-filled Inquiry Fields
  const [inquiryService, setInquiryService] = useState('Two-Piece Bespoke Suit');
  const [inquiryFabric, setInquiryFabric] = useState('');
  const [inquiryNotes, setInquiryNotes] = useState('');

  // Initial Fetch through unified apiClient
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [settings, catalog, fetchedOrders, fetchedMeas, fetchedInq, fetchedSubs] = await Promise.all([
          apiClient.getShopSettings(),
          apiClient.getCatalog(),
          apiClient.getOrders(),
          apiClient.getMeasurements(),
          apiClient.getInquiries(),
          apiClient.getSubscribers(),
        ]);

        if (settings) setShopSettings(settings);
        if (catalog) {
          if (catalog.services) setServices(catalog.services);
          if (catalog.fabrics) setFabrics(catalog.fabrics);
        }
        if (fetchedOrders) setOrders(fetchedOrders);
        if (fetchedMeas) setMeasurements(fetchedMeas);
        if (fetchedInq) setInquiries(fetchedInq);
        if (fetchedSubs) setSubscribers(fetchedSubs);

        // Check active session
        if (apiClient.getCurrentUser()) {
          setIsAdminLoggedIn(true);
        }
      } catch (err) {
        console.warn('Error loading initial data from apiClient:', err);
      }
    };

    fetchData();
  }, []);

  // Handler: Select service for Inquiry
  const handleSelectServiceForInquiry = (title: string, fabricName?: string) => {
    setInquiryService(title);
    if (fabricName) setInquiryFabric(fabricName);
    navigate('/inquiry');
  };

  // Handler: Select Mockup for Inquiry
  const handleSelectMockupForInquiry = (garmentTitle: string, fabricName: string, notes: string) => {
    setInquiryService(garmentTitle);
    setInquiryFabric(fabricName);
    setInquiryNotes(notes);
    navigate('/inquiry');
  };

  // Handler: Proceed from Size Fit Calculator to Inquiry
  const handleProceedToInquiryWithFit = (fitSummary: string) => {
    setInquiryNotes(fitSummary);
    navigate('/inquiry');
  };

  // Handler: Save Measurement to Database
  const handleSaveMeasurementToDatabase = async (data: any) => {
    try {
      const newMeas = await apiClient.createMeasurement(data);
      setMeasurements((prev) => [newMeas, ...prev]);
    } catch (err) {
      console.error('Error saving measurement profile:', err);
    }
  };

  // Handler: Search Orders
  const handleSearchOrders = async (query: string): Promise<Order[]> => {
    try {
      return await apiClient.lookupOrders(query);
    } catch (err) {
      console.error('Lookup error:', err);
      return [];
    }
  };

  // Handler: Submit Guest Inquiry
  const handleSubmitInquiry = async (inquiryData: any): Promise<boolean> => {
    try {
      const res = await apiClient.submitInquiry(inquiryData);
      if (res.success && res.inquiry) {
        setInquiries((prev) => [res.inquiry, ...prev]);
        return true;
      }
    } catch (err) {
      console.error('Inquiry submission error:', err);
    }
    return false;
  };

  // Handler: Subscribe to Email Mailing List
  const handleSubscribe = async (name: string, email: string, preference: string) => {
    const res = await apiClient.subscribe({ name, email, preference });
    if (res.subscriber) {
      setSubscribers((prev) => [res.subscriber!, ...prev]);
    }
    return { success: true, message: res.message };
  };

  // Admin Handlers
  const handleUpdateOrderStatus = async (
    id: string,
    status: OrderStatus,
    note?: string,
    paymentStatus?: PaymentStatus,
    fittingDate?: string
  ) => {
    try {
      const updated = await apiClient.updateOrderStatus(id, status, note, paymentStatus, fittingDate);
      setOrders((prev) => prev.map((o) => (o.id === id ? updated : o)));
    } catch (err) {
      console.error('Update status error:', err);
    }
  };

  const handleCreateOrder = async (orderData: any) => {
    try {
      const newOrder = await apiClient.createOrder(orderData);
      setOrders((prev) => [newOrder, ...prev]);
    } catch (err) {
      console.error('Create order error:', err);
    }
  };

  const handleCreateMeasurement = async (mData: any) => {
    try {
      const created = await apiClient.createMeasurement(mData);
      setMeasurements((prev) => [created, ...prev]);
    } catch (err) {
      console.error('Create measurement error:', err);
    }
  };

  const handleUpdateMeasurement = async (id: string, mData: any) => {
    try {
      const updated = await apiClient.updateMeasurement(id, mData);
      setMeasurements((prev) => prev.map((m) => (m.id === id ? updated : m)));
    } catch (err) {
      console.error('Update measurement error:', err);
    }
  };

  const handleAddService = async (serviceData: any) => {
    try {
      const created = await apiClient.addService(serviceData);
      setServices((prev) => [created, ...prev]);
    } catch (err) {
      console.error('Add service error:', err);
    }
  };

  const handleAddFabric = async (fabricData: any) => {
    try {
      const created = await apiClient.addFabric(fabricData);
      setFabrics((prev) => [created, ...prev]);
    } catch (err) {
      console.error('Add fabric error:', err);
    }
  };

  const handleUpdateInquiryStatus = async (id: string, status: string) => {
    try {
      const updated = await apiClient.updateInquiryStatus(id, status as any);
      setInquiries((prev) => prev.map((i) => (i.id === id ? updated : i)));
    } catch (err) {
      console.error('Update inquiry status error:', err);
    }
  };

  const handleUpdateShopSettings = async (settingsData: any) => {
    try {
      const updated = await apiClient.updateShopSettings(settingsData);
      setShopSettings(updated);
    } catch (err) {
      console.error('Update shop settings error:', err);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF9F6] text-stone-900 flex flex-col font-sans selection:bg-[#C5A059] selection:text-stone-950">
      <ScrollToTop />

      {/* Header */}
      <Header
        shopSettings={shopSettings}
        onOpenMailingList={() => setMailingListOpen(true)}
        onOpenAiAssistant={() => setAiAssistantOpen(true)}
        onOpenAdminLogin={() => setAdminLoginOpen(true)}
        isAdminLoggedIn={isAdminLoggedIn}
        onAdminLogout={() => {
          apiClient.logout();
          setIsAdminLoggedIn(false);
          navigate('/');
        }}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        <Routes>
          {/* Home / Catalog Route */}
          <Route
            path="/"
            element={
              <>
                <Hero
                  shopSettings={shopSettings}
                  onOpenMailingList={() => setMailingListOpen(true)}
                />
                <ServicesShowcase
                  services={services}
                  fabrics={fabrics}
                  shopSettings={shopSettings}
                  onSelectServiceForInquiry={handleSelectServiceForInquiry}
                />
                <ContactSection shopSettings={shopSettings} />
              </>
            }
          />

          {/* Catalog Alias */}
          <Route
            path="/catalog"
            element={
              <>
                <ServicesShowcase
                  services={services}
                  fabrics={fabrics}
                  shopSettings={shopSettings}
                  onSelectServiceForInquiry={handleSelectServiceForInquiry}
                />
                <ContactSection shopSettings={shopSettings} />
              </>
            }
          />

          {/* AI Visualizer Route */}
          <Route
            path="/visualizer"
            element={
              <>
                <GarmentMockupGenerator
                  fabrics={fabrics}
                  onSelectMockupForInquiry={handleSelectMockupForInquiry}
                />
                <ContactSection shopSettings={shopSettings} />
              </>
            }
          />

          {/* Fit & Size Calculator Route */}
          <Route
            path="/size-fit"
            element={
              <>
                <SizeFitAdvisor
                  onSaveMeasurementToDatabase={handleSaveMeasurementToDatabase}
                  onProceedToInquiryWithFit={handleProceedToInquiryWithFit}
                />
                <ContactSection shopSettings={shopSettings} />
              </>
            }
          />

          {/* Order Tracker Route */}
          <Route
            path="/tracker"
            element={
              <>
                <OrderTracker onSearchOrders={handleSearchOrders} />
                <ContactSection shopSettings={shopSettings} />
              </>
            }
          />

          {/* Order & Fitting Inquiry Route */}
          <Route
            path="/inquiry"
            element={
              <>
                <InquiryForm
                  initialService={inquiryService}
                  initialFabric={inquiryFabric}
                  initialFitNotes={inquiryNotes}
                  services={services}
                  fabrics={fabrics}
                  shopSettings={shopSettings}
                  onSubmitInquiry={handleSubmitInquiry}
                />
                <ContactSection shopSettings={shopSettings} />
              </>
            }
          />

          {/* Contact Atelier Route */}
          <Route
            path="/contact"
            element={<ContactSection shopSettings={shopSettings} />}
          />

          {/* Staff Admin Portal Route */}
          <Route
            path="/admin"
            element={
              isAdminLoggedIn ? (
                <AdminDashboard
                  orders={orders}
                  measurements={measurements}
                  services={services}
                  fabrics={fabrics}
                  inquiries={inquiries}
                  subscribers={subscribers}
                  shopSettings={shopSettings}
                  onUpdateOrderStatus={handleUpdateOrderStatus}
                  onCreateOrder={handleCreateOrder}
                  onCreateMeasurement={handleCreateMeasurement}
                  onUpdateMeasurement={handleUpdateMeasurement}
                  onAddService={handleAddService}
                  onAddFabric={handleAddFabric}
                  onUpdateInquiryStatus={handleUpdateInquiryStatus}
                  onUpdateShopSettings={handleUpdateShopSettings}
                />
              ) : (
                <div className="min-h-[60vh] flex flex-col items-center justify-center p-8 text-center space-y-4">
                  <h2 className="font-serif-title text-3xl font-normal text-stone-900">
                    Atelier Staff Authentication Required
                  </h2>
                  <p className="text-stone-600 text-sm max-w-md">
                    Please log in with your Staff Admin PIN or Credentials to manage orders, customer measurements, and catalog pricing.
                  </p>
                  <button
                    onClick={() => setAdminLoginOpen(true)}
                    className="px-6 py-3 rounded bg-stone-900 text-white font-semibold text-xs uppercase tracking-wider hover:bg-[#C5A059] hover:text-stone-950 transition-all"
                  >
                    Open Staff Portal Login
                  </button>
                </div>
              )
            }
          />

          {/* Fallback to Home */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      {/* Footer */}
      <footer className="bg-stone-950 text-stone-400 py-12 border-t border-stone-800 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-stone-800 pb-6">
            <div>
              <span className="font-serif-title text-xl text-white font-normal block">
                {shopSettings.shopName}
              </span>
              <p className="text-stone-500 text-[11px] mt-0.5">
                {shopSettings.tagline}
              </p>
            </div>

            <div className="flex items-center gap-4 text-stone-400">
              <Link to="/" className="hover:text-white">
                Services & Catalog
              </Link>
              <span>•</span>
              <Link to="/visualizer" className="hover:text-white">
                AI Visualizer
              </Link>
              <span>•</span>
              <Link to="/size-fit" className="hover:text-white">
                Size & Fit
              </Link>
              <span>•</span>
              <Link to="/tracker" className="hover:text-white">
                Live Order Tracker
              </Link>
              <span>•</span>
              <button onClick={() => setMailingListOpen(true)} className="text-[#C5A059] hover:underline">
                New Fabric Alerts
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-stone-500">
            <p>© {new Date().getFullYear()} {shopSettings.shopName}. All rights reserved. Single-business tailoring platform.</p>
            <p>Anatomical Body Measurements Saved Securely • Victoria Island, Lagos</p>
          </div>
        </div>
      </footer>

      {/* Modals & Drawers */}
      <MailingListModal
        isOpen={mailingListOpen}
        onClose={() => setMailingListOpen(false)}
        onSubscribe={handleSubscribe}
      />

      <AICraftAssistant
        isOpen={aiAssistantOpen}
        onClose={() => setAiAssistantOpen(false)}
        shopSettings={shopSettings}
      />

      <AdminLoginModal
        isOpen={adminLoginOpen}
        onClose={() => setAdminLoginOpen(false)}
        onLoginSuccess={() => {
          setIsAdminLoggedIn(true);
          setAdminLoginOpen(false);
          navigate('/admin');
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}
