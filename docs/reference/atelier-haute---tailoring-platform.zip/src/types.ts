export type OrderStatus =
  | 'placed'
  | 'confirmed'
  | 'fabric_cut'
  | 'in_production'
  | 'fitting_required'
  | 'ready'
  | 'delivered';

export type PaymentStatus = 'unpaid' | 'pending' | 'deposit_paid' | 'paid_in_full';

export interface MeasurementProfile {
  id: string;
  customerName: string;
  phone: string;
  email?: string;
  chest: number; // inches
  waist: number;
  shoulder: number;
  sleeve: number;
  neck: number;
  hip: number;
  inseam: number;
  heightCm?: number;
  preferredFit: 'slim' | 'classic' | 'relaxed';
  postureNotes?: string;
  updatedAt: string;
}

export interface Order {
  id: string; // e.g. ORD-2026-8832
  customerName: string;
  phone: string;
  email: string;
  serviceTitle: string;
  fabricName: string;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  totalPrice: number;
  depositAmount: number;
  estimatedCompletionDate: string;
  fittingDate?: string;
  measurementsId?: string;
  notes?: string;
  createdAt: string;
  history: {
    status: OrderStatus;
    timestamp: string;
    note?: string;
  }[];
}

export interface ServiceItem {
  id: string;
  title: string;
  category: 'bespoke_suit' | 'tuxedo' | 'traditional' | 'alteration' | 'restyling';
  startingPrice: number;
  turnaroundDays: number;
  description: string;
  features: string[];
  imageUrl: string;
}

export interface FabricOption {
  id: string;
  name: string;
  origin: string; // e.g., 'Savile Row, UK', 'Biella, Italy', 'Kano, Nigeria'
  composition: string; // e.g., 'Super 130s Merino Wool', 'Cashmere Blend', 'Heavy Silk Jacquard'
  colorHex: string;
  pattern: 'solid' | 'pinstripe' | 'check' | 'herringbone' | 'jacquard';
  priceTier: 'Standard' | 'Premium' | 'Luxury';
  inStock: boolean;
  imageUrl: string;
}

export interface GuestInquiry {
  id: string;
  customerName: string;
  phone: string;
  email: string;
  serviceRequested: string;
  fabricPreference?: string;
  preferredFittingDate?: string;
  message: string;
  status: 'new' | 'reviewed' | 'converted';
  createdAt: string;
}

export interface Subscriber {
  id: string;
  name: string;
  email: string;
  preference: 'all' | 'bespoke_drops' | 'fabric_arrivals' | 'style_guides';
  subscribedAt: string;
}

export interface ShopSettings {
  shopName: string;
  tagline: string;
  phone: string;
  email: string;
  address: string;
  cityCountry: string;
  hoursWeekday: string;
  hoursSaturday: string;
  hoursSunday: string;
  pricingNote: string;
  depositPercentage: number;
  adminPin: string;
}

export interface SizeCalculationInput {
  chestInches: number;
  waistInches: number;
  shoulderInches: number;
  heightCm: number;
  weightKg?: number;
}

export interface SizeFitResult {
  recommendedJacketSize: string; // e.g. "40R" or "42L"
  recommendedTrouserWaist: number;
  dropDiff: number; // chest - waist difference
  fitCategory: 'Athletic V-Drop' | 'Standard European Fit' | 'Comfort Executive Fit';
  fitNotes: string[];
  recommendedFitType: 'slim' | 'classic' | 'relaxed';
}

export interface MockupRequest {
  garmentType: string;
  fabricName: string;
  fabricColor: string;
  cutStyle: string; // e.g. 'Single Breasted 2-Button', 'Double Breasted 6-Button'
  lapelType: string; // e.g. 'Notch Lapel', 'Peak Lapel', 'Shawl Collar'
  additionalDetails?: string;
}

export interface AIChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}
