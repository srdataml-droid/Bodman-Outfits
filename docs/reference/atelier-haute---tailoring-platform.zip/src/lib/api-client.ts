import {
  FabricOption,
  GuestInquiry,
  MeasurementProfile,
  MockupRequest,
  Order,
  OrderStatus,
  PaymentStatus,
  ServiceItem,
  ShopSettings,
  Subscriber,
  AIChatMessage,
} from '../types';

import {
  initialFabrics,
  initialInquiries,
  initialMeasurements,
  initialOrders,
  initialServices,
  initialShopSettings,
  initialSubscribers,
} from '../data/initialData';

/**
 * API Data-Access Module (Unified Data Access Layer)
 * 
 * DEMO / PRODUCTION SWAP INSTRUCTION:
 * To switch from DEMO Mode to the NestJS production API, toggle `USE_MOCK` to `false`
 * and ensure `API_BASE_URL` points to your NestJS server endpoint.
 * 
 * Every component in this frontend calls `apiClient.*` methods exclusively.
 */
export const USE_MOCK = true;
export const API_BASE_URL = '/api';

// In-Memory Persistent Store for DEMO MODE session state
class MockStore {
  shopSettings: ShopSettings = { ...initialShopSettings };
  services: ServiceItem[] = [...initialServices];
  fabrics: FabricOption[] = [...initialFabrics];
  orders: Order[] = [...initialOrders];
  measurements: MeasurementProfile[] = [...initialMeasurements];
  inquiries: GuestInquiry[] = [...initialInquiries];
  subscribers: Subscriber[] = [...initialSubscribers];
  currentUser: { id: string; name: string; email: string; role: string; token: string } | null = null;

  constructor() {
    // Restore session if available
    try {
      const savedUser = localStorage.getItem('atelier_demo_user');
      if (savedUser) {
        this.currentUser = JSON.parse(savedUser);
      }
    } catch {
      // Ignore storage errors
    }
  }

  saveSession(user: { id: string; name: string; email: string; role: string; token: string } | null) {
    this.currentUser = user;
    if (user) {
      localStorage.setItem('atelier_demo_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('atelier_demo_user');
    }
  }
}

const mockStore = new MockStore();

// Helper to simulate asynchronous network latency for realistic UX behavior
const delay = (ms = 180) => new Promise((resolve) => setTimeout(resolve, ms));

export const apiClient = {
  /**
   * Get Shop Metadata & Settings
   */
  async getShopSettings(): Promise<ShopSettings> {
    if (USE_MOCK) {
      await delay();
      return { ...mockStore.shopSettings };
    }
    const res = await fetch(`${API_BASE_URL}/shop-settings`);
    if (!res.ok) throw new Error('Failed to fetch shop settings');
    return await res.json();
  },

  /**
   * Update Shop Settings
   */
  async updateShopSettings(data: Partial<ShopSettings>): Promise<ShopSettings> {
    if (USE_MOCK) {
      await delay();
      mockStore.shopSettings = { ...mockStore.shopSettings, ...data };
      return { ...mockStore.shopSettings };
    }
    const res = await fetch(`${API_BASE_URL}/shop-settings`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to update shop settings');
    const result = await res.json();
    return result.shopSettings || result;
  },

  /**
   * Fetch Catalog Services and Fabric Options
   */
  async getCatalog(): Promise<{ services: ServiceItem[]; fabrics: FabricOption[] }> {
    if (USE_MOCK) {
      await delay();
      return {
        services: [...mockStore.services],
        fabrics: [...mockStore.fabrics],
      };
    }
    const res = await fetch(`${API_BASE_URL}/catalog`);
    if (!res.ok) throw new Error('Failed to fetch catalog');
    return await res.json();
  },

  /**
   * Add a new service to catalog
   */
  async addService(data: Omit<ServiceItem, 'id'>): Promise<ServiceItem> {
    if (USE_MOCK) {
      await delay();
      const newService: ServiceItem = {
        id: `srv-${Date.now()}`,
        ...data,
      };
      mockStore.services.unshift(newService);
      return newService;
    }
    const res = await fetch(`${API_BASE_URL}/services`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to add service');
    return await res.json();
  },

  /**
   * Add a new fabric to catalog
   */
  async addFabric(data: Omit<FabricOption, 'id'>): Promise<FabricOption> {
    if (USE_MOCK) {
      await delay();
      const newFabric: FabricOption = {
        id: `fab-${Date.now()}`,
        ...data,
      };
      mockStore.fabrics.unshift(newFabric);
      return newFabric;
    }
    const res = await fetch(`${API_BASE_URL}/fabrics`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to add fabric');
    return await res.json();
  },

  /**
   * Fetch Orders
   */
  async getOrders(): Promise<Order[]> {
    if (USE_MOCK) {
      await delay();
      return [...mockStore.orders];
    }
    const res = await fetch(`${API_BASE_URL}/orders`);
    if (!res.ok) throw new Error('Failed to fetch orders');
    return await res.json();
  },

  /**
   * Order Lookup (by Order ID, phone number, or customer name)
   */
  async lookupOrders(query: string): Promise<Order[]> {
    const cleanQuery = query.trim().toLowerCase();
    if (!cleanQuery) return [];

    if (USE_MOCK) {
      await delay();
      const numQuery = cleanQuery.replace(/[^0-9]/g, '');
      return mockStore.orders.filter((o) => {
        const idMatch = o.id.toLowerCase().includes(cleanQuery);
        const nameMatch = o.customerName.toLowerCase().includes(cleanQuery);
        const phoneMatch = numQuery && o.phone.replace(/[^0-9]/g, '').includes(numQuery);
        return idMatch || nameMatch || phoneMatch;
      });
    }

    const res = await fetch(`${API_BASE_URL}/orders/lookup?q=${encodeURIComponent(query)}`);
    if (!res.ok) throw new Error('Order lookup failed');
    return await res.json();
  },

  /**
   * Create a new order
   */
  async createOrder(orderData: Partial<Order>): Promise<Order> {
    if (USE_MOCK) {
      await delay();
      const id = `ORD-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const newOrder: Order = {
        id,
        customerName: orderData.customerName || 'Valued Client',
        phone: orderData.phone || '+234 800 000 0000',
        email: orderData.email || '',
        serviceTitle: orderData.serviceTitle || 'Bespoke Garment',
        fabricName: orderData.fabricName || 'Selected Fabric',
        status: orderData.status || 'placed',
        paymentStatus: orderData.paymentStatus || 'deposit_paid',
        totalPrice: Number(orderData.totalPrice) || 350000,
        depositAmount: Number(orderData.depositAmount) || 175000,
        estimatedCompletionDate: orderData.estimatedCompletionDate || '2026-08-15',
        fittingDate: orderData.fittingDate || 'Pending scheduling',
        measurementsId: orderData.measurementsId,
        notes: orderData.notes || '',
        createdAt: new Date().toISOString(),
        history: [
          {
            status: orderData.status || 'placed',
            timestamp: new Date().toISOString(),
            note: 'Order created in Atelier system (DEMO)',
          },
        ],
      };
      mockStore.orders.unshift(newOrder);
      return newOrder;
    }

    const res = await fetch(`${API_BASE_URL}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData),
    });
    if (!res.ok) throw new Error('Failed to create order');
    return await res.json();
  },

  /**
   * Create Guest Order and Initialize Paystack Checkout (Test Mode)
   */
  async createGuestOrder(orderData: Partial<Order>): Promise<{
    success: boolean;
    order: Order;
    paymentUrl?: string;
    reference: string;
    error?: string;
  }> {
    const res = await fetch(`${API_BASE_URL}/orders/guest`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData),
    });
    const data = await res.json();
    if (!res.ok) {
      if (data.order) {
        const existingIdx = mockStore.orders.findIndex((o) => o.id === data.order.id);
        if (existingIdx === -1) mockStore.orders.unshift(data.order);
      }
      throw new Error(data.error || 'Failed to initialize Paystack checkout.');
    }
    if (data.order) {
      const existingIdx = mockStore.orders.findIndex((o) => o.id === data.order.id);
      if (existingIdx === -1) mockStore.orders.unshift(data.order);
    }
    return data;
  },

  /**
   * Server-side Verify Paystack Payment
   */
  async verifyPaystackPayment(reference: string): Promise<{
    success: boolean;
    verified: boolean;
    order?: Order;
    transaction?: any;
    error?: string;
  }> {
    const res = await fetch(`${API_BASE_URL}/paystack/verify/${encodeURIComponent(reference)}`);
    const data = await res.json();
    if (data.order) {
      const existingIdx = mockStore.orders.findIndex((o) => o.id === data.order.id);
      if (existingIdx !== -1) {
        mockStore.orders[existingIdx] = data.order;
      } else {
        mockStore.orders.unshift(data.order);
      }
    }
    if (!res.ok) {
      return {
        success: false,
        verified: false,
        error: data.error || data.message || 'Payment verification failed',
      };
    }
    return data;
  },


  /**
   * Update Order Status & Notes
   */
  async updateOrderStatus(
    id: string,
    status: OrderStatus,
    note?: string,
    paymentStatus?: PaymentStatus,
    fittingDate?: string
  ): Promise<Order> {
    if (USE_MOCK) {
      await delay();
      const order = mockStore.orders.find((o) => o.id === id);
      if (!order) throw new Error('Order not found');

      if (status && status !== order.status) {
        order.status = status;
        order.history.unshift({
          status,
          timestamp: new Date().toISOString(),
          note: note || `Order status updated to ${status.replace('_', ' ')}`,
        });
      }
      if (paymentStatus) order.paymentStatus = paymentStatus;
      if (fittingDate) order.fittingDate = fittingDate;

      return { ...order };
    }

    const res = await fetch(`${API_BASE_URL}/orders/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, note, paymentStatus, fittingDate }),
    });
    if (!res.ok) throw new Error('Failed to update order status');
    return await res.json();
  },

  /**
   * Fetch Measurement Profiles
   */
  async getMeasurements(): Promise<MeasurementProfile[]> {
    if (USE_MOCK) {
      await delay();
      return [...mockStore.measurements];
    }
    const res = await fetch(`${API_BASE_URL}/measurements`);
    if (!res.ok) throw new Error('Failed to fetch measurements');
    return await res.json();
  },

  /**
   * Create Measurement Profile
   */
  async createMeasurement(data: Partial<MeasurementProfile>): Promise<MeasurementProfile> {
    if (USE_MOCK) {
      await delay();
      const newMeas: MeasurementProfile = {
        id: `meas-${Date.now()}`,
        customerName: data.customerName || 'Valued Client',
        phone: data.phone || '+234 800 000 0000',
        email: data.email || '',
        chest: Number(data.chest) || 40,
        waist: Number(data.waist) || 32,
        shoulder: Number(data.shoulder) || 18,
        sleeve: Number(data.sleeve) || 25,
        neck: Number(data.neck) || 16,
        hip: Number(data.hip) || 40,
        inseam: Number(data.inseam) || 32,
        heightCm: Number(data.heightCm) || 180,
        preferredFit: data.preferredFit || 'classic',
        postureNotes: data.postureNotes || '',
        updatedAt: new Date().toISOString(),
      };
      mockStore.measurements.unshift(newMeas);
      return newMeas;
    }

    const res = await fetch(`${API_BASE_URL}/measurements`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to save measurement profile');
    return await res.json();
  },

  /**
   * Update Measurement Profile
   */
  async updateMeasurement(id: string, data: Partial<MeasurementProfile>): Promise<MeasurementProfile> {
    if (USE_MOCK) {
      await delay();
      const idx = mockStore.measurements.findIndex((m) => m.id === id);
      if (idx === -1) throw new Error('Measurement profile not found');

      mockStore.measurements[idx] = {
        ...mockStore.measurements[idx],
        ...data,
        updatedAt: new Date().toISOString(),
      };
      return { ...mockStore.measurements[idx] };
    }

    const res = await fetch(`${API_BASE_URL}/measurements/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to update measurement profile');
    return await res.json();
  },

  /**
   * Fetch Guest Inquiries
   */
  async getInquiries(): Promise<GuestInquiry[]> {
    if (USE_MOCK) {
      await delay();
      return [...mockStore.inquiries];
    }
    const res = await fetch(`${API_BASE_URL}/inquiries`);
    if (!res.ok) throw new Error('Failed to fetch inquiries');
    return await res.json();
  },

  /**
   * Submit Guest Inquiry
   */
  async submitInquiry(
    data: Omit<GuestInquiry, 'id' | 'status' | 'createdAt'>
  ): Promise<{ success: boolean; inquiry: GuestInquiry }> {
    if (USE_MOCK) {
      await delay();
      const newInquiry: GuestInquiry = {
        id: `inq-${Date.now()}`,
        ...data,
        status: 'new',
        createdAt: new Date().toISOString(),
      };
      mockStore.inquiries.unshift(newInquiry);
      return { success: true, inquiry: newInquiry };
    }

    const res = await fetch(`${API_BASE_URL}/inquiries`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to submit inquiry');
    return await res.json();
  },

  /**
   * Update Inquiry Status
   */
  async updateInquiryStatus(id: string, status: 'new' | 'reviewed' | 'converted'): Promise<GuestInquiry> {
    if (USE_MOCK) {
      await delay();
      const inq = mockStore.inquiries.find((i) => i.id === id);
      if (!inq) throw new Error('Inquiry not found');
      inq.status = status;
      return { ...inq };
    }

    const res = await fetch(`${API_BASE_URL}/inquiries/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (!res.ok) throw new Error('Failed to update inquiry status');
    return await res.json();
  },

  /**
   * Fetch Subscribers
   */
  async getSubscribers(): Promise<Subscriber[]> {
    if (USE_MOCK) {
      await delay();
      return [...mockStore.subscribers];
    }
    const res = await fetch(`${API_BASE_URL}/subscribers`);
    if (!res.ok) throw new Error('Failed to fetch subscribers');
    return await res.json();
  },

  /**
   * Subscribe to Mailing List
   */
  async subscribe(data: {
    name: string;
    email: string;
    preference: string;
  }): Promise<{ success: boolean; subscriber?: Subscriber; message: string }> {
    if (USE_MOCK) {
      await delay();
      if (!data.email || !data.email.includes('@')) {
        throw new Error('Valid email address is required.');
      }
      const existing = mockStore.subscribers.find(
        (s) => s.email.toLowerCase() === data.email.toLowerCase()
      );
      if (existing) {
        return { success: true, message: 'You are already subscribed to Atelier Haute announcements.' };
      }

      const newSub: Subscriber = {
        id: `sub-${Date.now()}`,
        name: data.name || 'Valued Client',
        email: data.email,
        preference: (data.preference as any) || 'all',
        subscribedAt: new Date().toISOString(),
      };
      mockStore.subscribers.unshift(newSub);
      return {
        success: true,
        subscriber: newSub,
        message: 'Thank you for subscribing to our bespoke collection announcements.',
      };
    }

    const res = await fetch(`${API_BASE_URL}/subscribers`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const result = await res.json();
    if (!res.ok) throw new Error(result.error || 'Subscription failed');
    return result;
  },

  /**
   * Admin Auth Login (DEMO MODE / Backend Contract)
   * Follows standard POST auth contract returning user object & token
   */
  async login(credentials: {
    email?: string;
    password?: string;
    pin?: string;
  }): Promise<{ user: { id: string; name: string; email: string; role: string; token: string } }> {
    if (USE_MOCK) {
      await delay(300);
      // Validate credentials against shopSettings.adminPin or email/password
      const inputPin = credentials.pin || credentials.password;
      const isValidPin = inputPin === mockStore.shopSettings.adminPin;
      const isValidEmail = credentials.email?.toLowerCase().includes('admin') || credentials.email === 'admin@atelierhaute.com';

      if (!isValidPin && !isValidEmail && inputPin !== '1234') {
        throw new Error('Invalid Staff Admin Credentials or PIN.');
      }

      const user = {
        id: 'usr-admin-01',
        name: 'Master Tailor Staff',
        email: credentials.email || 'admin@atelierhaute.com',
        role: 'admin',
        token: `demo-jwt-token-${Date.now()}`,
      };

      mockStore.saveSession(user);
      return { user };
    }

    const res = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials),
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || err.error || 'Authentication failed');
    }

    const data = await res.json();
    mockStore.saveSession(data.user);
    return data;
  },

  /**
   * Check current staff user session
   */
  getCurrentUser() {
    return mockStore.currentUser;
  },

  /**
   * Staff Admin Logout
   */
  logout() {
    mockStore.saveSession(null);
  },

  /**
   * AI Concierge Assistant
   * Checks for Ollama Cloud / Gemini API or falls back to rule-based demo concierge
   */
  async askAIConcierge(
    userMessage: string,
    conversationHistory?: AIChatMessage[]
  ): Promise<{ reply: string; isRealAI: boolean; source: 'Ollama Cloud AI' | 'Rule-based Demo Concierge' }> {
    // Attempt real API endpoint if available
    try {
      const res = await fetch(`${API_BASE_URL}/ai-assistant`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userMessage, conversationHistory }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.reply) {
          // Check if server returned a real AI response or rule fallback
          const isRealAI = !data.isFallback;
          return {
            reply: data.reply,
            isRealAI,
            source: isRealAI ? 'Ollama Cloud AI' : 'Rule-based Demo Concierge',
          };
        }
      }
    } catch {
      // Fall through to local rule-based fallback
    }

    await delay(350);
    const lower = userMessage.toLowerCase();
    const settings = mockStore.shopSettings;

    let responseText = `Welcome to ${settings.shopName}. We specialize in bespoke suits, wedding tuxedos, traditional attire, and master alterations. How may I assist your wardrobe requirements today?`;

    if (lower.includes('price') || lower.includes('cost') || lower.includes('how much') || lower.includes('tier')) {
      responseText = `Our bespoke suits start from ₦380,000 for a two-piece suit and ₦460,000 for a three-piece executive suit. Wedding tuxedos start at ₦520,000. All orders include consultation, canvas fittings, and precision adjustments. A ${settings.depositPercentage}% deposit confirms your order.`;
    } else if (lower.includes('hour') || lower.includes('open') || lower.includes('time') || lower.includes('address') || lower.includes('location') || lower.includes('where')) {
      responseText = `Our atelier is located at ${settings.address}, ${settings.cityCountry}. We are open Monday to Friday from ${settings.hoursWeekday}, Saturdays from ${settings.hoursSaturday}, and Sundays by appointment. Direct Line: ${settings.phone}.`;
    } else if (lower.includes('turnaround') || lower.includes('how long') || lower.includes('days') || lower.includes('timeframe') || lower.includes('rush')) {
      responseText = `A two-piece bespoke suit typically takes 14 days, including 2 canvas fitting sessions. Master alterations take approximately 4 days. Express turnaround can be accommodated upon request.`;
    } else if (lower.includes('track') || lower.includes('status') || lower.includes('order') || lower.includes('lookup')) {
      responseText = `You can easily track your order live using our Order Tracker! Simply enter your Order Ref Number (e.g., ORD-2026-8832) or phone number in the Track Order section.`;
    } else if (lower.includes('fabric') || lower.includes('wool') || lower.includes('silk') || lower.includes('linen') || lower.includes('velvet')) {
      responseText = `We stock over 5 premium fabrics sourced from Biella (Italy), Huddersfield (UK), Lyon (France), and Kano (Nigeria) — ranging from Super 130s Merino Wools to heavy Silk Brocades.`;
    } else if (lower.includes('fit') || lower.includes('measure') || lower.includes('size') || lower.includes('calculator')) {
      responseText = `Our online Fit & Size Calculator uses anatomical drop ratios to determine your exact jacket size and fit profile. Try it in the Fit & Size Calculator section!`;
    }

    return {
      reply: responseText,
      isRealAI: false,
      source: 'Rule-based Demo Concierge',
    };
  },

  /**
   * Garment Mockup Generator (Returns curated placeholder preview image)
   */
  async generateMockup(request: MockupRequest): Promise<{
    success: boolean;
    imageUrl: string;
    promptUsed: string;
    description: string;
    isDemo: boolean;
  }> {
    await delay(500);

    const promptUsed = `Luxury editorial photograph of a bespoke menswear ${request.garmentType} in ${request.fabricName} (${request.fabricColor}). Cut: ${request.cutStyle}, Lapel: ${request.lapelType}. Details: ${request.additionalDetails || 'Handcrafted Savile Row finish'}.`;

    // Curated high quality garment preview placeholder image
    const placeholderImages: Record<string, string> = {
      bespoke_suit: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=800&q=80',
      tuxedo: 'https://images.unsplash.com/photo-1598808503746-f34c53b9323e?auto=format&fit=crop&w=800&q=80',
      traditional: 'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=800&q=80',
      executive: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80',
    };

    const imageUrl = placeholderImages[request.garmentType.toLowerCase()] || placeholderImages.bespoke_suit;

    return {
      success: true,
      imageUrl,
      promptUsed,
      description: `Bespoke ${request.garmentType} in ${request.fabricName} (${request.fabricColor}) featuring ${request.lapelType} and ${request.cutStyle}.`,
      isDemo: true,
    };
  },
};
