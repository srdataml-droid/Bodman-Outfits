import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';

import {
  initialFabrics,
  initialInquiries,
  initialMeasurements,
  initialOrders,
  initialServices,
  initialShopSettings,
  initialSubscribers,
} from './src/data/initialData.js';
import {
  FabricOption,
  GuestInquiry,
  MeasurementProfile,
  MockupRequest,
  Order,
  ServiceItem,
  ShopSettings,
  Subscriber,
} from './src/types.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '10mb' }));

// In-Memory Database state for instant responsiveness and live admin sync
let shopSettings: ShopSettings = { ...initialShopSettings };
let services: ServiceItem[] = [...initialServices];
let fabrics: FabricOption[] = [...initialFabrics];
let orders: Order[] = [...initialOrders];
let measurements: MeasurementProfile[] = [...initialMeasurements];
let inquiries: GuestInquiry[] = [...initialInquiries];
let subscribers: Subscriber[] = [...initialSubscribers];

// Helper to initialize Gemini SDK safely
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// ------------------- API ENDPOINTS -------------------

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Shop Settings
app.get('/api/shop-settings', (req, res) => {
  res.json(shopSettings);
});

app.put('/api/shop-settings', (req, res) => {
  const { pin, ...newSettings } = req.body;
  if (pin !== shopSettings.adminPin) {
    return res.status(401).json({ error: 'Unauthorized: Invalid Admin PIN' });
  }
  shopSettings = { ...shopSettings, ...newSettings };
  res.json({ success: true, shopSettings });
});

// Services & Fabrics
app.get('/api/catalog', (req, res) => {
  res.json({ services, fabrics });
});

app.post('/api/services', (req, res) => {
  const newService: ServiceItem = {
    id: `srv-${Date.now()}`,
    ...req.body,
  };
  services.unshift(newService);
  res.status(201).json(newService);
});

app.put('/api/services/:id', (req, res) => {
  const { id } = req.params;
  const index = services.findIndex((s) => s.id === id);
  if (index === -1) return res.status(404).json({ error: 'Service not found' });
  services[index] = { ...services[index], ...req.body };
  res.json(services[index]);
});

app.post('/api/fabrics', (req, res) => {
  const newFabric: FabricOption = {
    id: `fab-${Date.now()}`,
    ...req.body,
  };
  fabrics.unshift(newFabric);
  res.status(201).json(newFabric);
});

// Order Lookup & Management
app.get('/api/orders/lookup', (req, res) => {
  const query = (req.query.q as string || '').trim().toLowerCase();
  if (!query) {
    return res.status(400).json({ error: 'Please enter an Order ID or phone number' });
  }

  const found = orders.filter(
    (o) =>
      o.id.toLowerCase() === query ||
      o.phone.replace(/[^0-9]/g, '').includes(query.replace(/[^0-9]/g, '')) ||
      o.customerName.toLowerCase().includes(query)
  );

  res.json(found);
});

app.get('/api/orders', (req, res) => {
  res.json(orders);
});

// Guest Order Creation with Paystack Transaction Initialization
app.post('/api/orders/guest', async (req, res) => {
  const {
    customerName,
    phone,
    email,
    serviceTitle,
    fabricName,
    totalPrice,
    depositAmount,
    notes,
    fittingDate,
    measurementsId,
  } = req.body;

  if (!customerName || !phone || !email) {
    return res.status(400).json({ error: 'Name, phone number, and email address are required.' });
  }

  const id = `ORD-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const calcTotal = Number(totalPrice) || 380000;
  const calcDeposit = Number(depositAmount) || Math.round(calcTotal * 0.5);

  const newOrder: Order = {
    id,
    customerName,
    phone,
    email,
    serviceTitle: serviceTitle || 'Bespoke Garment',
    fabricName: fabricName || 'Atelier Selected Fabric',
    status: 'placed',
    paymentStatus: 'pending',
    totalPrice: calcTotal,
    depositAmount: calcDeposit,
    estimatedCompletionDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
    fittingDate: fittingDate || 'Pending scheduling',
    measurementsId: measurementsId || undefined,
    notes: notes || '',
    createdAt: new Date().toISOString(),
    history: [
      {
        status: 'placed',
        timestamp: new Date().toISOString(),
        note: 'Guest order created; awaiting Paystack test deposit payment',
      },
    ],
  };

  orders.unshift(newOrder);

  const paystackSecretKey = process.env.PAYSTACK_SECRET_KEY;
  if (!paystackSecretKey) {
    return res.status(400).json({
      error: 'PAYSTACK_SECRET_KEY environment variable is missing. Please configure PAYSTACK_SECRET_KEY (sk_test_...) in your environment settings.',
      order: newOrder,
    });
  }

  try {
    const origin = req.headers.origin || `${req.protocol}://${req.get('host')}`;
    const callbackUrl = `${origin}/tracker?reference=${id}&verify=paystack`;

    const paystackRes = await fetch('https://api.paystack.co/transaction/initialize', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${paystackSecretKey.trim()}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email,
        amount: Math.round(calcDeposit * 100), // convert NGN to Kobo
        reference: id,
        callback_url: callbackUrl,
        metadata: {
          order_id: id,
          customer_name: customerName,
          phone,
          service_title: newOrder.serviceTitle,
        },
      }),
    });

    const paystackData = await paystackRes.json();

    if (!paystackRes.ok || !paystackData.status) {
      return res.status(400).json({
        error: paystackData.message || 'Paystack transaction initialization failed',
        details: paystackData,
        order: newOrder,
      });
    }

    return res.status(201).json({
      success: true,
      order: newOrder,
      paymentUrl: paystackData.data.authorization_url,
      reference: id,
      accessCode: paystackData.data.access_code,
    });
  } catch (err: any) {
    console.error('Paystack initialize error:', err);
    return res.status(500).json({
      error: err.message || 'Failed to communicate with Paystack API',
      order: newOrder,
    });
  }
});

// Paystack Server-side Transaction Verification
const verifyPaystackTx = async (reference: string, res: express.Response) => {
  const paystackSecretKey = process.env.PAYSTACK_SECRET_KEY;
  if (!paystackSecretKey) {
    return res.status(400).json({
      error: 'PAYSTACK_SECRET_KEY environment variable is missing.',
    });
  }

  try {
    const paystackRes = await fetch(
      `https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,
      {
        headers: {
          Authorization: `Bearer ${paystackSecretKey.trim()}`,
        },
      }
    );

    const paystackData = await paystackRes.json();

    if (!paystackRes.ok || !paystackData.status) {
      return res.status(400).json({
        success: false,
        verified: false,
        error: paystackData.message || 'Paystack verification failed',
      });
    }

    const tx = paystackData.data;
    const refId = tx.reference || reference;
    const order = orders.find((o) => o.id === refId || o.id === reference);

    if (tx.status === 'success') {
      if (order) {
        order.paymentStatus = order.depositAmount >= order.totalPrice ? 'paid_in_full' : 'deposit_paid';
        order.status = 'confirmed';

        const alreadyRecorded = order.history.some((h) => h.note?.includes('Paystack'));
        if (!alreadyRecorded) {
          order.history.unshift({
            status: 'confirmed',
            timestamp: new Date().toISOString(),
            note: `Paystack test payment verified (Ref: ${tx.reference}, Channel: ${tx.channel}, Amount: ₦${(tx.amount / 100).toLocaleString()})`,
          });
        }
      }

      return res.json({
        success: true,
        verified: true,
        order,
        transaction: {
          reference: tx.reference,
          amount: tx.amount / 100,
          currency: tx.currency,
          paidAt: tx.paid_at,
          channel: tx.channel,
          status: tx.status,
          gatewayResponse: tx.gateway_response,
        },
      });
    } else {
      return res.status(400).json({
        success: false,
        verified: false,
        order,
        message: `Transaction status: ${tx.status}`,
      });
    }
  } catch (err: any) {
    return res.status(500).json({
      error: err.message || 'Error communicating with Paystack verification endpoint',
    });
  }
};

app.get('/api/paystack/verify/:reference', (req, res) => {
  verifyPaystackTx(req.params.reference, res);
});

app.post('/api/paystack/verify', (req, res) => {
  const reference = req.body.reference || req.body.trxref;
  if (!reference) {
    return res.status(400).json({ error: 'Reference parameter is required' });
  }
  verifyPaystackTx(reference, res);
});

app.post('/api/orders', (req, res) => {
  const id = `ORD-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const newOrder: Order = {
    id,
    customerName: req.body.customerName,
    phone: req.body.phone,
    email: req.body.email || '',
    serviceTitle: req.body.serviceTitle,
    fabricName: req.body.fabricName,
    status: req.body.status || 'placed',
    paymentStatus: req.body.paymentStatus || 'deposit_paid',
    totalPrice: Number(req.body.totalPrice) || 350000,
    depositAmount: Number(req.body.depositAmount) || 175000,
    estimatedCompletionDate: req.body.estimatedCompletionDate || '2026-08-15',
    fittingDate: req.body.fittingDate || 'Pending scheduling',
    measurementsId: req.body.measurementsId || undefined,
    notes: req.body.notes || '',
    createdAt: new Date().toISOString(),
    history: [
      {
        status: req.body.status || 'placed',
        timestamp: new Date().toISOString(),
        note: 'Order created in Atelier system',
      },
    ],
  };
  orders.unshift(newOrder);
  res.status(201).json(newOrder);
});

app.put('/api/orders/:id/status', (req, res) => {
  const { id } = req.params;
  const { status, note, paymentStatus, fittingDate } = req.body;
  const order = orders.find((o) => o.id === id);
  if (!order) return res.status(404).json({ error: 'Order not found' });

  if (status && status !== order.status) {
    order.status = status;
    order.history.unshift({
      status,
      timestamp: new Date().toISOString(),
      note: note || `Order updated to ${status.replace('_', ' ')}`,
    });
  }
  if (paymentStatus) order.paymentStatus = paymentStatus;
  if (fittingDate) order.fittingDate = fittingDate;

  res.json(order);
});

// Customer Measurements
app.get('/api/measurements', (req, res) => {
  res.json(measurements);
});

app.post('/api/measurements', (req, res) => {
  const newMeas: MeasurementProfile = {
    id: `meas-${Date.now()}`,
    customerName: req.body.customerName,
    phone: req.body.phone,
    email: req.body.email || '',
    chest: Number(req.body.chest) || 40,
    waist: Number(req.body.waist) || 32,
    shoulder: Number(req.body.shoulder) || 18,
    sleeve: Number(req.body.sleeve) || 25,
    neck: Number(req.body.neck) || 16,
    hip: Number(req.body.hip) || 40,
    inseam: Number(req.body.inseam) || 32,
    heightCm: Number(req.body.heightCm) || 180,
    preferredFit: req.body.preferredFit || 'classic',
    postureNotes: req.body.postureNotes || '',
    updatedAt: new Date().toISOString(),
  };
  measurements.unshift(newMeas);
  res.status(201).json(newMeas);
});

app.put('/api/measurements/:id', (req, res) => {
  const { id } = req.params;
  const index = measurements.findIndex((m) => m.id === id);
  if (index === -1) return res.status(404).json({ error: 'Measurement profile not found' });

  measurements[index] = {
    ...measurements[index],
    ...req.body,
    updatedAt: new Date().toISOString(),
  };
  res.json(measurements[index]);
});

// Guest Inquiries
app.get('/api/inquiries', (req, res) => {
  res.json(inquiries);
});

app.post('/api/inquiries', (req, res) => {
  const newInquiry: GuestInquiry = {
    id: `inq-${Date.now()}`,
    customerName: req.body.customerName,
    phone: req.body.phone,
    email: req.body.email,
    serviceRequested: req.body.serviceRequested,
    fabricPreference: req.body.fabricPreference,
    preferredFittingDate: req.body.preferredFittingDate,
    message: req.body.message || '',
    status: 'new',
    createdAt: new Date().toISOString(),
  };
  inquiries.unshift(newInquiry);
  res.status(201).json({ success: true, inquiry: newInquiry });
});

app.put('/api/inquiries/:id/status', (req, res) => {
  const { id } = req.params;
  const inquiry = inquiries.find((i) => i.id === id);
  if (!inquiry) return res.status(404).json({ error: 'Inquiry not found' });
  inquiry.status = req.body.status || 'reviewed';
  res.json(inquiry);
});

// Email Mailing List Subscription
app.get('/api/subscribers', (req, res) => {
  res.json(subscribers);
});

app.post('/api/subscribers', (req, res) => {
  const { name, email, preference } = req.body;
  if (!email || !email.includes('@')) {
    return res.status(400).json({ error: 'Valid email address is required.' });
  }

  const existing = subscribers.find((s) => s.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    return res.json({ message: 'You are already subscribed to Atelier Haute announcements.' });
  }

  const newSub: Subscriber = {
    id: `sub-${Date.now()}`,
    name: name || 'Valued Client',
    email,
    preference: preference || 'all',
    subscribedAt: new Date().toISOString(),
  };
  subscribers.unshift(newSub);
  res.status(201).json({ success: true, subscriber: newSub, message: 'Thank you for subscribing to our bespoke collection announcements.' });
});

// ------------------- GEMINI AI FEATURES -------------------

// 1. AI Garment Mockup Generator Endpoint
app.post('/api/mockup', async (req, res) => {
  const { garmentType, fabricName, fabricColor, cutStyle, lapelType, additionalDetails } = req.body as MockupRequest;

  const prompt = `A studio photograph of a bespoke menswear ${garmentType} handcrafted in ${fabricName} (${fabricColor}).
Cut style: ${cutStyle}, featuring ${lapelType}.
Details: ${additionalDetails || 'Impeccable Savile Row craftsmanship, natural shoulder line, sharp drape, high contrast lighting on a dark alabaster studio backdrop'}.
Style: Luxury menswear editorial photograph, photorealistic, sharp focus, 8k resolution.`;

  try {
    const ai = getGeminiClient();
    if (ai) {
      try {
        const aiRes = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite-image',
          contents: {
            parts: [{ text: prompt }],
          },
          config: {
            imageConfig: {
              aspectRatio: '3:4',
            },
          },
        });

        if (aiRes.candidates?.[0]?.content?.parts) {
          for (const part of aiRes.candidates[0].content.parts) {
            if (part.inlineData?.data) {
              const imageUrl = `data:image/png;base64,${part.inlineData.data}`;
              return res.json({
                success: true,
                imageUrl,
                promptUsed: prompt,
                description: `Bespoke ${garmentType} in ${fabricName} with ${lapelType} and ${cutStyle}.`,
              });
            }
          }
        }
      } catch (imgErr) {
        console.warn('Gemini image generation attempt fallback:', imgErr);
      }
    }

    // High quality curated bespoke mockup placeholder fallback if AI image quota/key is limited
    const placeholderUrl = `https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=800&q=80`;
    res.json({
      success: true,
      imageUrl: placeholderUrl,
      promptUsed: prompt,
      description: `Bespoke ${garmentType} in ${fabricName} featuring ${lapelType} and ${cutStyle}. Impeccably drafted fit.`,
      isFallback: true,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to generate garment mockup' });
  }
});

// 2. AI Craft Assistant Concierge Endpoint
app.post('/api/ai-assistant', async (req, res) => {
  const { userMessage, conversationHistory } = req.body;

  if (!userMessage) {
    return res.status(400).json({ error: 'Message content is required' });
  }

  const shopContext = `
You are the Master Concierge for '${shopSettings.shopName}', a premier luxury bespoke tailoring house in ${shopSettings.cityCountry}.
Store Details:
- Address: ${shopSettings.address}, ${shopSettings.cityCountry}
- Phone: ${shopSettings.phone} | Email: ${shopSettings.email}
- Opening Hours: Mon-Fri (${shopSettings.hoursWeekday}), Sat (${shopSettings.hoursSaturday}), Sun (${shopSettings.hoursSunday})
- Pricing Policy: ${shopSettings.pricingNote} (Deposit requirement: ${shopSettings.depositPercentage}%)

Available Services:
${services.map((s) => `- ${s.title}: Starting from ₦${s.startingPrice.toLocaleString()} (Turnaround: ${s.turnaroundDays} days). ${s.description}`).join('\n')}

Fabric Selection:
${fabrics.map((f) => `- ${f.name} (${f.origin}, ${f.composition}): ${f.priceTier} tier, Pattern: ${f.pattern}`).join('\n')}

Order & Fitting Process:
1. Initial Consultation & Precise Body Measurement recording.
2. Fabric selection and canvas baseline drafting.
3. First basted fitting (canvas baseline check).
4. Second refinement fitting (sleeve pitch, collar roll, trouser drape).
5. Final hand pressing & delivery/pickup.

Tone: Professional, warm, respectful, knowledgeable about fine textiles, suits, traditional attire, and tailoring terminology. Keep answers concise, helpful, and elegant.
`;

  try {
    const ai = getGeminiClient();
    if (!ai) {
      // Rule-based elegant assistant fallback when process.env.GEMINI_API_KEY is not set
      const lower = userMessage.toLowerCase();
      let responseText = `Welcome to ${shopSettings.shopName}. We specialize in bespoke suits, wedding tuxedos, traditional attire, and master alterations. How may I assist your wardrobe requirements today?`;

      if (lower.includes('price') || lower.includes('cost') || lower.includes('how much')) {
        responseText = `Our bespoke suits start from ₦380,000 for a two-piece suit and ₦460,000 for a three-piece executive suit. Wedding tuxedos start at ₦520,000. All orders include consultation, canvas fittings, and precision adjustments. A ${shopSettings.depositPercentage}% deposit confirms your order.`;
      } else if (lower.includes('hour') || lower.includes('open') || lower.includes('time') || lower.includes('address') || lower.includes('location')) {
        responseText = `Our atelier is located at ${shopSettings.address}, ${shopSettings.cityCountry}. We are open Monday to Friday from ${shopSettings.hoursWeekday}, Saturdays from ${shopSettings.hoursSaturday}, and Sundays by appointment. Phone: ${shopSettings.phone}.`;
      } else if (lower.includes('turnaround') || lower.includes('how long') || lower.includes('days') || lower.includes('timeframe')) {
        responseText = `A two-piece bespoke suit typically takes 14 days, including 2 canvas fitting sessions. Master alterations take approximately 4 days. Rush services can be arranged upon request.`;
      } else if (lower.includes('track') || lower.includes('status') || lower.includes('order')) {
        responseText = `You can easily track your order live using our Order Tracker! Simply enter your Order Ref Number (e.g., ORD-2026-8832) or phone number in the Tracker tab.`;
      }

      return res.json({ reply: responseText });
    }

    const contents = [];
    if (Array.isArray(conversationHistory)) {
      for (const msg of conversationHistory) {
        contents.push({
          role: msg.sender === 'user' ? 'user' : 'model',
          parts: [{ text: msg.text }],
        });
      }
    }
    contents.push({ role: 'user', parts: [{ text: userMessage }] });

    const aiRes = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents,
      config: {
        systemInstruction: shopContext,
        temperature: 0.7,
      },
    });

    const reply = aiRes.text || 'I am delighted to assist with your bespoke tailoring inquiry. Please let me know how I may help further.';
    res.json({ reply });
  } catch (err: any) {
    console.error('AI Concierge error:', err);
    res.json({
      reply: `At Atelier Haute, we pride ourselves on precision tailoring. You can contact our concierge directly at ${shopSettings.phone} or send us an inquiry through our booking page.`,
    });
  }
});

// ------------------- VITE SERVING & LAUNCH -------------------

async function startServer() {
  const PORT = 3000;

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Atelier Haute Tailoring Platform active on http://0.0.0.0:${PORT}`);
  });
}

startServer();
