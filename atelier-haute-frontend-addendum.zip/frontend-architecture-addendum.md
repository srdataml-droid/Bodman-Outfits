# Atelier Haute — Frontend Architecture & Design Addendum

**Purpose:** This document extends the existing AGENTS.md / api.md spec. It captures decisions made after the Home + Catalogue build, covering the two-app split, the custom design request feature, and the design language mapping for whichever agent (Codex or Claude Code) picks up the remaining pages.

**Status:** Business is menswear-only. Owner (Lord Noir's father) builds suits, corporate wear, and casual outfits. Bridal/native-wear categories from the original Relume/Stitch mockups do not apply — do not build them.

---

## 1. Repo Structure

Single Turborepo monorepo. Do not split into separate repos.

```
apps/
  web/      # customer-facing site (public, multi-page, "pro" front-end)
  admin/    # NEW — internal ops app (order management, custom request review)
  api/      # NestJS backend (existing)
packages/
  ui/       # NEW — shared design tokens + components used by both web and admin
```

Both `web` and `admin` consume `packages/ui` for shared tokens (colors, type scale, spacing) so they stay visually consistent even though `admin` is visually much plainer. Do not let `admin` diverge on core tokens — only on density and motion.

`admin` is **not linked from `web`** anywhere in the UI. No footer link, no hidden route hint in the public sitemap. Separate subdomain or path convention, decided later — flag as an open question, don't block on it.

---

## 2. Catalogue Categories (confirmed, replaces earlier Relume/Stitch structure)

- **Suits** — business, wedding, event
- **Corporate** — blazers, trousers, shirts, office-appropriate separates
- **Casual** — everyday menswear

Casual vs. native/traditional wear (agbada, senator, kaftan) is **still unresolved** — pending a direct answer from the business owner. Do not build a native-wear category yet. If it turns out he does make these, they likely fold into the custom design request flow (see below) rather than becoming a fourth top-level category, until confirmed otherwise.

---

## 3. NEW FEATURE: Custom Design Request Flow

This is in addition to the existing "customize an existing catalogue piece" flow (browse a made piece → request changes to it). This new flow handles requests that start from the customer's own idea, not from an existing catalogue item.

**Customer side (`apps/web`):**
- A "Request a custom design" entry point, separate from the catalogue's per-item "Customize" button.
- Form fields: description (free text), optional reference image upload, optional link to closest catalogue category (Suits/Corporate/Casual) for context.
- On submit: request enters status `pending_review`. Customer sees confirmation with plain-language expectation setting ("We'll review this and get back to you within [X] — pending real answer from owner").

**Admin side (`apps/admin`):**
- Queue view of pending custom requests, sorted oldest-first.
- Each request: accept (converts to a real order, proceeds to measurements/payment per existing order flow) or decline (requires a reason, sent back to customer).
- This queue is the first real feature to build in `admin` — it's the clearest, most self-contained piece, good starting point once `admin` scaffolding exists.

**Data model note for `api.md`:** needs a `CustomRequest` entity distinct from `Order`, with a status enum (`pending_review`, `accepted`, `declined`), a `reviewedBy` admin reference, and a `declineReason` nullable field. Add this to the Prisma schema when `admin` work begins — not yet built.

---

## 4. Design Language Mapping

Design references are studied for their **approach**, not copied wholesale. No fake quotes, no direct visual copying — these inform decisions, not dictate them.

| Reference | Studied for | Applied to |
|---|---|---|
| Emil Kowalski | Micro-interaction timing, easing curves | Both apps — hover states, transition timing |
| Rauno Freiberg | Tactile, physics-based response | `web` — garment cards, customize-flow interactions |
| Linear | Density, speed, zero decoration | `admin` — entire app, especially the custom-request queue |
| Paystack / Flutterwave / Moniepoint | Proof that disciplined, polished design reads well to a Nigerian audience without importing a foreign SaaS look | `web` — overall visual restraint, load performance |
| Josh Comeau | Implementation reference for *why* animations work | Any agent building GSAP/Motion code — troubleshooting reference, not a look |

**Design emphasis (confirmed by owner):** customer-centric warmth. This is primarily a **copy and interaction** decision, not a visual one:
- Order status and confirmation copy should read like a person wrote it: "Your suit is with the tailor now," not "Status: In Progress."
- Custom request confirmations and admin decline messages should feel attentive, never templated/automated-sounding.
- Booking/appointment confirmation flow gets the same treatment.
- This does not mean more decoration — it means the *words* carry warmth while the layout stays disciplined (per the existing Everglade/Copper/Tan token system already confirmed).

---

## 5. Motion Library Assignments

- **GSAP** — scroll-triggered reveals on `web` Home/Catalogue, hero video transition (tailor-at-work footage → text reveal, pending Lord Noir's fuller description of the vision).
- **Motion (Framer Motion successor)** — component-level transitions inside `web`: customize-flow modal, custom-request form steps, page-to-page transitions.
- **Lenis** — smooth scroll across `web` only.
- **`admin` gets none of the above.** Deliberately plain — fast, keyboard-friendly, no scroll/motion libraries. This is intentional per the Linear reference above, not a placeholder gap.

Performance guardrail (Nigerian market, confirmed as a co-equal priority with cultural fit): compressed video, poster-frame fallbacks, lazy-loaded images, `prefers-reduced-motion` respected everywhere — required, not optional, per the existing quality floor already documented in ui-ux.md.

---

## 6. Still Open — Do Not Block On, But Track

1. Does "casual" include native/traditional wear, or does that route through the custom request flow? (owner TBD)
2. Admin subdomain/path convention for `apps/admin`.
3. Hero video — full creative direction still pending from Lord Noir.
4. All core business content: real business name, pricing, turnaround time, deposit %, cancellation policy, real garment photography. (See prior 26-item question list — unchanged, still pending conversation with owner.)

None of these block starting `apps/admin` scaffolding or the remaining `web` pages (Book an Appointment, Enquiry, FAQ, About) — those can proceed with the same placeholder-content boundary already documented in ui-ux.md.
